#!/bin/bash

# PACKS Backend Setup Script
echo "🚀 Configurando PACKS Backend..."

# Check if Python 3.8+ is installed
python_version=$(python3 --version 2>&1 | grep -Po '(?<=Python )\d+\.\d+')
required_version="3.8"

if [ "$(printf '%s\n' "$required_version" "$python_version" | sort -V | head -n1)" != "$required_version" ]; then
    echo "❌ Python 3.8+ é necessário. Versão atual: $python_version"
    exit 1
fi

echo "✅ Python $python_version encontrado"

# Create virtual environment
if [ ! -d "venv" ]; then
    echo "🐍 Criando ambiente virtual..."
    python3 -m venv venv
else
    echo "✅ Ambiente virtual já existe"
fi

# Activate virtual environment
echo "🔧 Ativando ambiente virtual..."
source venv/bin/activate

# Upgrade pip
echo "📦 Atualizando pip..."
pip install --upgrade pip

# Ask for installation type
echo ""
echo "📋 Escolha o tipo de instalação:"
echo "1) Desenvolvimento (requirements-dev.txt) - Recomendado para desenvolvimento"
echo "2) Produção (requirements-prod.txt) - Para deploy em produção"
echo "3) Básico (requirements.txt) - Instalação mínima"
echo ""
read -p "Digite sua escolha (1-3): " choice

case $choice in
    1)
        echo "📥 Instalando dependências de desenvolvimento..."
        pip install -r requirements-dev.txt
        ;;
    2)
        echo "📥 Instalando dependências de produção..."
        pip install -r requirements-prod.txt
        ;;
    3)
        echo "📥 Instalando dependências básicas..."
        pip install -r requirements.txt
        ;;
    *)
        echo "📥 Opção inválida, instalando dependências básicas..."
        pip install -r requirements.txt
        ;;
esac

# Create .env file if it doesn't exist
if [ ! -f ".env" ]; then
    echo "⚙️ Criando arquivo .env..."
    cp .env.example .env
    echo "📝 Por favor, configure as variáveis no arquivo .env"
else
    echo "✅ Arquivo .env já existe"
fi

# Create database directory
mkdir -p database
mkdir -p logs

# Initialize database
echo "🗄️ Inicializando banco de dados..."
python -c "
from app import create_app
from app.models import db

app = create_app()
with app.app_context():
    db.create_all()
    print('✅ Banco de dados inicializado')
"

echo ""
echo "✅ Setup concluído!"
echo ""
echo "📋 Próximos passos:"
echo "1. Configure as variáveis de ambiente no arquivo .env"
echo "2. Execute 'python run.py' para iniciar o servidor"
echo "3. Acesse http://localhost:5000/api/health para verificar"
echo ""
echo "🔗 Comandos úteis:"
echo "  python run.py                    - Iniciar servidor de desenvolvimento"
echo "  pytest                          - Executar testes"
echo "  black app/                      - Formatar código"
echo "  flake8 app/                     - Verificar estilo"
echo ""
echo "📚 Documentação:"
echo "  docs/api.md                     - Documentação da API"
echo "  docs/development.md             - Guia de desenvolvimento"

