#!/usr/bin/env python3
"""
Arquivo principal para executar a aplicação Flask
"""

import os
from app import create_app

# Criar aplicação
app = create_app()

if __name__ == '__main__':
    # Configurações para desenvolvimento
    debug_mode = os.environ.get('FLASK_DEBUG', 'True').lower() in ['true', '1', 'on']
    port = int(os.environ.get('PORT', 5000))
    host = os.environ.get('HOST', '0.0.0.0')
    
    print(f"🚀 Iniciando servidor Flask em http://{host}:{port}")
    print(f"📊 Modo debug: {debug_mode}")
    print(f"🌍 Ambiente: {os.environ.get('FLASK_ENV', 'development')}")
    
    app.run(
        host=host,
        port=port,
        debug=debug_mode,
        threaded=True
    )

