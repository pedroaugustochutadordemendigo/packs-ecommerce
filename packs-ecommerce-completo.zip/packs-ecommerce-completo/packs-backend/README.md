# PACKS Backend API

🚀 **API REST para o e-commerce de streetwear PACKS**

Uma API moderna e escalável construída com Flask, SQLAlchemy e as melhores práticas de desenvolvimento.

## 📋 Índice

- [Tecnologias](#-tecnologias)
- [Instalação](#-instalação)
- [Configuração](#-configuração)
- [Execução](#-execução)
- [Estrutura do Projeto](#-estrutura-do-projeto)
- [API Endpoints](#-api-endpoints)
- [Desenvolvimento](#-desenvolvimento)
- [Testes](#-testes)
- [Deploy](#-deploy)

## 🛠️ Tecnologias

- **Python 3.8+** - Linguagem de programação
- **Flask 2.3+** - Framework web
- **SQLAlchemy 2.0+** - ORM para banco de dados
- **Flask-JWT-Extended** - Autenticação JWT
- **Marshmallow** - Serialização e validação
- **Flask-CORS** - Suporte a CORS
- **Gunicorn** - Servidor WSGI para produção
- **SQLite/PostgreSQL** - Banco de dados

## 🚀 Instalação

### Pré-requisitos

- Python 3.8 ou superior
- pip (gerenciador de pacotes Python)
- Git

### Clonando o Repositório

```bash
git clone https://github.com/packs-streetwear/packs-backend.git
cd packs-backend
```

### Configuração do Ambiente

1. **Criar ambiente virtual:**
```bash
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows
```

2. **Instalar dependências:**

Para desenvolvimento:
```bash
pip install -r requirements-dev.txt
```

Para produção:
```bash
pip install -r requirements-prod.txt
```

Para instalação básica:
```bash
pip install -r requirements.txt
```

## ⚙️ Configuração

1. **Criar arquivo de ambiente:**
```bash
cp .env.example .env
```

2. **Configurar variáveis no arquivo `.env`:**
```env
# Aplicação
FLASK_ENV=development
FLASK_DEBUG=True
SECRET_KEY=your-super-secret-key-here

# Banco de dados
DATABASE_URL=sqlite:///database/packs.db

# CORS
CORS_ORIGINS=http://localhost:3000,http://localhost:5173

# JWT
JWT_SECRET_KEY=your-jwt-secret-key-here
JWT_ACCESS_TOKEN_EXPIRES=3600

# Email (opcional)
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password
```

3. **Inicializar banco de dados:**
```bash
python -c "from app import create_app; from app.models import db; app = create_app(); app.app_context().push(); db.create_all()"
```

## 🏃‍♂️ Execução

### Desenvolvimento
```bash
python run.py
```

### Produção
```bash
gunicorn -w 4 -b 0.0.0.0:5000 "app:create_app()"
```

### Com Docker
```bash
docker build -t packs-backend .
docker run -p 5000:5000 packs-backend
```

## 📁 Estrutura do Projeto

```
packs-backend/
├── app/                     # Código principal da aplicação
│   ├── __init__.py         # Factory da aplicação Flask
│   ├── config.py           # Configurações da aplicação
│   ├── models/             # Modelos de dados (SQLAlchemy)
│   │   ├── __init__.py
│   │   ├── user.py         # Modelo de usuário
│   │   ├── product.py      # Modelo de produto
│   │   └── order.py        # Modelo de pedido
│   ├── routes/             # Rotas da API (Blueprints)
│   │   ├── __init__.py
│   │   ├── auth.py         # Autenticação e autorização
│   │   ├── products.py     # Gestão de produtos
│   │   ├── cart.py         # Carrinho de compras
│   │   ├── orders.py       # Gestão de pedidos
│   │   ├── admin.py        # Painel administrativo
│   │   ├── payments.py     # Processamento de pagamentos
│   │   ├── shipping.py     # Cálculo de frete
│   │   └── social.py       # Newsletter e contato
│   ├── schemas/            # Schemas de validação (Marshmallow)
│   │   ├── __init__.py
│   │   ├── user.py         # Schemas de usuário
│   │   ├── product.py      # Schemas de produto
│   │   └── order.py        # Schemas de pedido
│   ├── services/           # Lógica de negócio
│   │   ├── __init__.py
│   │   ├── auth_service.py # Serviços de autenticação
│   │   ├── product_service.py # Serviços de produto
│   │   └── order_service.py # Serviços de pedido
│   ├── utils/              # Utilitários e helpers
│   │   ├── __init__.py
│   │   ├── decorators.py   # Decoradores customizados
│   │   ├── validators.py   # Validadores customizados
│   │   └── helpers.py      # Funções auxiliares
│   └── database/           # Arquivos de banco de dados
├── tests/                  # Testes automatizados
│   ├── __init__.py
│   ├── unit/              # Testes unitários
│   ├── integration/       # Testes de integração
│   └── conftest.py        # Configurações de teste
├── docs/                  # Documentação
│   ├── api.md             # Documentação da API
│   ├── deployment.md      # Guia de deploy
│   └── development.md     # Guia de desenvolvimento
├── scripts/               # Scripts utilitários
│   ├── setup.sh          # Script de configuração
│   ├── deploy.sh         # Script de deploy
│   └── backup.sh         # Script de backup
├── migrations/            # Migrações de banco de dados
├── requirements.txt       # Dependências básicas
├── requirements-dev.txt   # Dependências de desenvolvimento
├── requirements-prod.txt  # Dependências de produção
├── run.py                 # Arquivo principal para execução
├── .env.example          # Exemplo de variáveis de ambiente
├── .gitignore            # Arquivos ignorados pelo Git
├── Dockerfile            # Configuração Docker
└── README.md             # Este arquivo
```

## 🔌 API Endpoints

### Autenticação
- `POST /api/auth/register` - Registrar novo usuário
- `POST /api/auth/login` - Login de usuário
- `POST /api/auth/logout` - Logout de usuário
- `GET /api/auth/me` - Dados do usuário logado
- `PUT /api/auth/profile` - Atualizar perfil

### Produtos
- `GET /api/products/` - Listar produtos (com filtros)
- `GET /api/products/{id}` - Detalhes de um produto
- `GET /api/products/categories` - Listar categorias
- `GET /api/products/featured` - Produtos em destaque
- `GET /api/products/search` - Buscar produtos

### Carrinho
- `GET /api/cart/` - Obter carrinho do usuário
- `POST /api/cart/add` - Adicionar item ao carrinho
- `PUT /api/cart/update/{item_id}` - Atualizar quantidade
- `DELETE /api/cart/remove/{item_id}` - Remover item
- `DELETE /api/cart/clear` - Limpar carrinho

### Pedidos
- `GET /api/orders/` - Listar pedidos do usuário
- `GET /api/orders/{id}` - Detalhes de um pedido
- `POST /api/orders/create` - Criar novo pedido
- `PUT /api/orders/{id}/status` - Atualizar status (admin)

### Administração
- `GET /api/admin/dashboard` - Dashboard administrativo
- `GET /api/admin/orders` - Todos os pedidos
- `GET /api/admin/users` - Todos os usuários
- `POST /api/admin/products` - Criar produto
- `PUT /api/admin/products/{id}` - Atualizar produto
- `DELETE /api/admin/products/{id}` - Deletar produto

## 🧪 Desenvolvimento

### Formatação de Código
```bash
# Formatação automática
black app/
isort app/

# Verificação de estilo
flake8 app/

# Verificação de tipos
mypy app/
```

### Migrações de Banco
```bash
# Inicializar migrações
flask db init

# Criar migração
flask db migrate -m "Descrição da migração"

# Aplicar migrações
flask db upgrade
```

### Variáveis de Ambiente de Desenvolvimento
```env
FLASK_ENV=development
FLASK_DEBUG=True
DATABASE_URL=sqlite:///database/packs_dev.db
```

## 🧪 Testes

### Executar Todos os Testes
```bash
pytest
```

### Testes com Cobertura
```bash
pytest --cov=app --cov-report=html
```

### Testes Específicos
```bash
# Testes unitários
pytest tests/unit/

# Testes de integração
pytest tests/integration/

# Teste específico
pytest tests/unit/test_auth.py
```

## 🚀 Deploy

### Heroku
```bash
# Login no Heroku
heroku login

# Criar aplicação
heroku create packs-backend-api

# Configurar variáveis de ambiente
heroku config:set FLASK_ENV=production
heroku config:set SECRET_KEY=your-production-secret

# Deploy
git push heroku main
```

### Docker
```bash
# Build da imagem
docker build -t packs-backend .

# Executar container
docker run -p 5000:5000 --env-file .env packs-backend
```

### VPS/Servidor
```bash
# Usar script de deploy
./scripts/deploy.sh production
```

## 📊 Monitoramento

### Logs
```bash
# Ver logs em desenvolvimento
tail -f logs/app.log

# Ver logs em produção (Heroku)
heroku logs --tail
```

### Health Check
```bash
curl http://localhost:5000/api/health
```

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/nova-feature`)
3. Commit suas mudanças (`git commit -am 'Adiciona nova feature'`)
4. Push para a branch (`git push origin feature/nova-feature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 📞 Suporte

- **Email:** packsorganization@gmail.com
- **Documentação:** [docs/](docs/)
- **Issues:** [GitHub Issues](https://github.com/packs-streetwear/packs-backend/issues)

---

**PACKS Streetwear** - Streetwear autêntico para quem não passa despercebido.

