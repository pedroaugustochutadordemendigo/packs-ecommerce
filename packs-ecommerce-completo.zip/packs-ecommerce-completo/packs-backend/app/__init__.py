from flask import Flask
from flask_cors import CORS
from .config import get_config
from .models import db

def create_app(config_name=None):
    """Factory function para criar a aplicação Flask"""
    
    app = Flask(__name__)
    
    # Carregar configuração
    if config_name:
        from .config import config
        app.config.from_object(config[config_name])
    else:
        app.config.from_object(get_config())
    
    # Configurar CORS
    CORS(app, 
         origins=app.config.get('CORS_ORIGINS', ['*']),
         supports_credentials=True,
         allow_headers=['Content-Type', 'Authorization'],
         methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'])
    
    # Inicializar extensões
    db.init_app(app)
    
    # Registrar blueprints
    from .routes import register_blueprints
    register_blueprints(app)
    
    # Criar tabelas do banco de dados
    with app.app_context():
        db.create_all()
    
    # Configurar handlers de erro
    @app.errorhandler(404)
    def not_found(error):
        return {'error': 'Recurso não encontrado'}, 404
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return {'error': 'Erro interno do servidor'}, 500
    
    @app.errorhandler(400)
    def bad_request(error):
        return {'error': 'Requisição inválida'}, 400
    
    # Endpoint de saúde
    @app.route('/api/health', methods=['GET'])
    def health_check():
        """Endpoint de verificação de saúde da API"""
        return {
            'status': 'healthy',
            'message': 'Packs E-commerce API is running',
            'version': '1.0.0'
        }
    
    # Servir arquivos estáticos do frontend (para produção)
    @app.route('/', defaults={'path': ''})
    @app.route('/<path:path>')
    def serve_frontend(path):
        """Serve o frontend React em produção"""
        import os
        from flask import send_from_directory, send_file
        
        static_folder = os.path.join(app.root_path, '..', '..', 'frontend', 'dist')
        
        if path and os.path.exists(os.path.join(static_folder, path)):
            return send_from_directory(static_folder, path)
        else:
            index_path = os.path.join(static_folder, 'index.html')
            if os.path.exists(index_path):
                return send_file(index_path)
            else:
                return {'message': 'Frontend não encontrado'}, 404
    
    return app

