from flask import Blueprint, request, jsonify

social_bp = Blueprint('social', __name__)

@social_bp.route('/links', methods=['GET'])
def get_social_links():
    """Obter links das redes sociais"""
    try:
        social_links = {
            'instagram': 'https://instagram.com/packs_streetwear',
            'facebook': 'https://facebook.com/packsstreetwearbr',
            'whatsapp': 'https://wa.me/5535999999999',
            'email': 'packsorganization@gmail.com'
        }
        
        return {'social_links': social_links}, 200
        
    except Exception as e:
        return {'error': f'Erro ao buscar links sociais: {str(e)}'}, 500

@social_bp.route('/newsletter/subscribe', methods=['POST'])
def subscribe_newsletter():
    """Inscrever-se na newsletter"""
    try:
        data = request.get_json()
        
        if not data.get('email'):
            return {'error': 'Email é obrigatório'}, 400
        
        # Simular inscrição na newsletter
        # Em produção, aqui seria integrado com serviço de email marketing
        
        return {
            'message': 'Inscrição realizada com sucesso!',
            'email': data['email']
        }, 200
        
    except Exception as e:
        return {'error': f'Erro ao inscrever na newsletter: {str(e)}'}, 500

@social_bp.route('/contact', methods=['POST'])
def send_contact():
    """Enviar mensagem de contato"""
    try:
        data = request.get_json()
        
        required_fields = ['name', 'email', 'message']
        for field in required_fields:
            if not data.get(field):
                return {'error': f'Campo {field} é obrigatório'}, 400
        
        # Simular envio de email de contato
        # Em produção, aqui seria enviado email real
        
        return {
            'message': 'Mensagem enviada com sucesso! Entraremos em contato em breve.'
        }, 200
        
    except Exception as e:
        return {'error': f'Erro ao enviar mensagem: {str(e)}'}, 500

