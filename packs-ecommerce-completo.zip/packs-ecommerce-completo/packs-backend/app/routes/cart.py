from flask import Blueprint, request, jsonify, session
from ..models import db, Product, ProductVariant, Cart, CartItem
import uuid

cart_bp = Blueprint('cart', __name__)

def get_or_create_cart():
    """Obter ou criar carrinho para o usuário/sessão"""
    user_id = session.get('user_id')
    session_id = session.get('cart_session_id')
    
    if not session_id:
        session_id = str(uuid.uuid4())
        session['cart_session_id'] = session_id
    
    # Buscar carrinho existente
    if user_id:
        cart = Cart.query.filter_by(user_id=user_id).first()
        # Se usuário fez login, migrar carrinho da sessão
        if not cart:
            session_cart = Cart.query.filter_by(session_id=session_id).first()
            if session_cart:
                session_cart.user_id = user_id
                session_cart.session_id = None
                db.session.commit()
                cart = session_cart
    else:
        cart = Cart.query.filter_by(session_id=session_id).first()
    
    # Criar novo carrinho se não existir
    if not cart:
        cart = Cart(
            user_id=user_id if user_id else None,
            session_id=session_id if not user_id else None
        )
        db.session.add(cart)
        db.session.commit()
    
    return cart

@cart_bp.route('/', methods=['GET'])
def get_cart():
    """Obter carrinho atual"""
    try:
        cart = get_or_create_cart()
        
        return {
            'cart': cart.to_dict()
        }, 200
        
    except Exception as e:
        return {'error': f'Erro ao obter carrinho: {str(e)}'}, 500

@cart_bp.route('/add', methods=['POST'])
def add_to_cart():
    """Adicionar item ao carrinho"""
    try:
        data = request.get_json()
        
        # Validar dados obrigatórios
        if not data.get('product_id'):
            return {'error': 'ID do produto é obrigatório'}, 400
        
        product_id = data['product_id']
        variant_id = data.get('variant_id')
        quantity = data.get('quantity', 1)
        
        # Validar quantidade
        if quantity <= 0:
            return {'error': 'Quantidade deve ser maior que zero'}, 400
        
        # Verificar se produto existe e está ativo
        product = Product.query.filter_by(id=product_id, is_active=True).first()
        if not product:
            return {'error': 'Produto não encontrado'}, 404
        
        # Verificar variação se especificada
        variant = None
        if variant_id:
            variant = ProductVariant.query.filter_by(
                id=variant_id,
                product_id=product_id,
                is_active=True
            ).first()
            if not variant:
                return {'error': 'Variação não encontrada'}, 404
        
        # Verificar estoque
        available_stock = variant.stock_quantity if variant else product.stock_quantity
        if available_stock < quantity:
            return {'error': f'Estoque insuficiente. Disponível: {available_stock}'}, 400
        
        # Obter carrinho
        cart = get_or_create_cart()
        
        # Verificar se item já existe no carrinho
        existing_item = CartItem.query.filter_by(
            cart_id=cart.id,
            product_id=product_id,
            variant_id=variant_id
        ).first()
        
        if existing_item:
            # Verificar se a nova quantidade não excede o estoque
            new_quantity = existing_item.quantity + quantity
            if new_quantity > available_stock:
                return {'error': f'Quantidade total excede estoque. Disponível: {available_stock}'}, 400
            
            existing_item.quantity = new_quantity
            existing_item.updated_at = db.func.now()
        else:
            # Criar novo item
            new_item = CartItem(
                cart_id=cart.id,
                product_id=product_id,
                variant_id=variant_id,
                quantity=quantity,
                unit_price=product.price
            )
            db.session.add(new_item)
        
        cart.updated_at = db.func.now()
        db.session.commit()
        
        return {
            'message': 'Item adicionado ao carrinho',
            'cart': cart.to_dict()
        }, 200
        
    except Exception as e:
        db.session.rollback()
        return {'error': f'Erro ao adicionar item: {str(e)}'}, 500

@cart_bp.route('/update/<int:item_id>', methods=['PUT'])
def update_cart_item(item_id):
    """Atualizar quantidade de item no carrinho"""
    try:
        data = request.get_json()
        quantity = data.get('quantity')
        
        if quantity is None or quantity < 0:
            return {'error': 'Quantidade inválida'}, 400
        
        # Obter carrinho
        cart = get_or_create_cart()
        
        # Buscar item no carrinho
        item = CartItem.query.filter_by(id=item_id, cart_id=cart.id).first()
        if not item:
            return {'error': 'Item não encontrado no carrinho'}, 404
        
        # Se quantidade for 0, remover item
        if quantity == 0:
            db.session.delete(item)
        else:
            # Verificar estoque
            available_stock = item.variant.stock_quantity if item.variant else item.product.stock_quantity
            if quantity > available_stock:
                return {'error': f'Quantidade excede estoque. Disponível: {available_stock}'}, 400
            
            item.quantity = quantity
            item.updated_at = db.func.now()
        
        cart.updated_at = db.func.now()
        db.session.commit()
        
        return {
            'message': 'Item atualizado',
            'cart': cart.to_dict()
        }, 200
        
    except Exception as e:
        db.session.rollback()
        return {'error': f'Erro ao atualizar item: {str(e)}'}, 500

@cart_bp.route('/remove/<int:item_id>', methods=['DELETE'])
def remove_cart_item(item_id):
    """Remover item do carrinho"""
    try:
        # Obter carrinho
        cart = get_or_create_cart()
        
        # Buscar item no carrinho
        item = CartItem.query.filter_by(id=item_id, cart_id=cart.id).first()
        if not item:
            return {'error': 'Item não encontrado no carrinho'}, 404
        
        db.session.delete(item)
        cart.updated_at = db.func.now()
        db.session.commit()
        
        return {
            'message': 'Item removido do carrinho',
            'cart': cart.to_dict()
        }, 200
        
    except Exception as e:
        db.session.rollback()
        return {'error': f'Erro ao remover item: {str(e)}'}, 500

@cart_bp.route('/clear', methods=['DELETE'])
def clear_cart():
    """Limpar todos os itens do carrinho"""
    try:
        cart = get_or_create_cart()
        
        # Remover todos os itens
        CartItem.query.filter_by(cart_id=cart.id).delete()
        cart.updated_at = db.func.now()
        db.session.commit()
        
        return {
            'message': 'Carrinho limpo',
            'cart': cart.to_dict()
        }, 200
        
    except Exception as e:
        db.session.rollback()
        return {'error': f'Erro ao limpar carrinho: {str(e)}'}, 500

@cart_bp.route('/count', methods=['GET'])
def get_cart_count():
    """Obter número total de itens no carrinho"""
    try:
        cart = get_or_create_cart()
        
        return {
            'count': cart.total_items,
            'total_amount': float(cart.total_amount)
        }, 200
        
    except Exception as e:
        return {'error': f'Erro ao obter contagem: {str(e)}'}, 500

@cart_bp.route('/validate', methods=['POST'])
def validate_cart():
    """Validar itens do carrinho (estoque, preços, etc.)"""
    try:
        cart = get_or_create_cart()
        
        issues = []
        
        for item in cart.items:
            # Verificar se produto ainda está ativo
            if not item.product.is_active:
                issues.append({
                    'item_id': item.id,
                    'type': 'product_inactive',
                    'message': f'Produto "{item.product.name}" não está mais disponível'
                })
                continue
            
            # Verificar estoque
            available_stock = item.variant.stock_quantity if item.variant else item.product.stock_quantity
            if item.quantity > available_stock:
                issues.append({
                    'item_id': item.id,
                    'type': 'insufficient_stock',
                    'message': f'Estoque insuficiente para "{item.product.name}". Disponível: {available_stock}',
                    'available_quantity': available_stock
                })
            
            # Verificar se preço mudou
            current_price = item.product.price
            if item.unit_price != current_price:
                issues.append({
                    'item_id': item.id,
                    'type': 'price_changed',
                    'message': f'Preço de "{item.product.name}" foi atualizado',
                    'old_price': float(item.unit_price),
                    'new_price': float(current_price)
                })
        
        return {
            'valid': len(issues) == 0,
            'issues': issues,
            'cart': cart.to_dict()
        }, 200
        
    except Exception as e:
        return {'error': f'Erro ao validar carrinho: {str(e)}'}, 500

