from flask import Blueprint, request, jsonify
from sqlalchemy import or_, and_, desc, asc
from ..models import db, Product, Category, ProductVariant

products_bp = Blueprint('products', __name__)

@products_bp.route('/', methods=['GET'])
def get_products():
    """Listar produtos com filtros e paginação"""
    try:
        # Parâmetros de filtro
        category = request.args.get('category')
        size = request.args.get('size')
        min_price = request.args.get('min_price', type=float)
        max_price = request.args.get('max_price', type=float)
        search = request.args.get('search')
        is_new = request.args.get('is_new', type=bool)
        is_on_sale = request.args.get('is_on_sale', type=bool)
        is_featured = request.args.get('is_featured', type=bool)
        
        # Parâmetros de paginação
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 12, type=int)
        
        # Parâmetros de ordenação
        sort_by = request.args.get('sort_by', 'created_at')
        sort_order = request.args.get('sort_order', 'desc')
        
        # Query base - apenas produtos ativos
        query = Product.query.filter(Product.is_active == True)
        
        # Aplicar filtros
        if category and category != 'all':
            query = query.join(Category).filter(Category.slug == category)
        
        if size and size != 'all':
            query = query.join(ProductVariant).filter(ProductVariant.size == size)
        
        if min_price is not None:
            query = query.filter(Product.price >= min_price)
        
        if max_price is not None:
            query = query.filter(Product.price <= max_price)
        
        if search:
            search_term = f"%{search}%"
            query = query.filter(
                or_(
                    Product.name.ilike(search_term),
                    Product.description.ilike(search_term),
                    Product.short_description.ilike(search_term)
                )
            )
        
        if is_new is not None:
            query = query.filter(Product.is_new == is_new)
        
        if is_on_sale is not None:
            query = query.filter(Product.is_on_sale == is_on_sale)
        
        if is_featured is not None:
            query = query.filter(Product.is_featured == is_featured)
        
        # Aplicar ordenação
        if sort_by == 'price':
            if sort_order == 'asc':
                query = query.order_by(asc(Product.price))
            else:
                query = query.order_by(desc(Product.price))
        elif sort_by == 'name':
            if sort_order == 'asc':
                query = query.order_by(asc(Product.name))
            else:
                query = query.order_by(desc(Product.name))
        else:  # created_at (padrão)
            if sort_order == 'asc':
                query = query.order_by(asc(Product.created_at))
            else:
                query = query.order_by(desc(Product.created_at))
        
        # Aplicar paginação
        pagination = query.paginate(
            page=page,
            per_page=per_page,
            error_out=False
        )
        
        products = pagination.items
        
        return {
            'products': [product.to_dict() for product in products],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': pagination.total,
                'pages': pagination.pages,
                'has_next': pagination.has_next,
                'has_prev': pagination.has_prev,
                'next_num': pagination.next_num,
                'prev_num': pagination.prev_num
            }
        }, 200
        
    except Exception as e:
        return {'error': f'Erro ao buscar produtos: {str(e)}'}, 500

@products_bp.route('/<int:product_id>', methods=['GET'])
def get_product(product_id):
    """Obter detalhes de um produto específico"""
    try:
        product = Product.query.filter_by(id=product_id, is_active=True).first()
        
        if not product:
            return {'error': 'Produto não encontrado'}, 404
        
        return {'product': product.to_dict()}, 200
        
    except Exception as e:
        return {'error': f'Erro ao buscar produto: {str(e)}'}, 500

@products_bp.route('/slug/<string:slug>', methods=['GET'])
def get_product_by_slug(slug):
    """Obter produto pelo slug"""
    try:
        product = Product.query.filter_by(slug=slug, is_active=True).first()
        
        if not product:
            return {'error': 'Produto não encontrado'}, 404
        
        return {'product': product.to_dict()}, 200
        
    except Exception as e:
        return {'error': f'Erro ao buscar produto: {str(e)}'}, 500

@products_bp.route('/categories', methods=['GET'])
def get_categories():
    """Listar todas as categorias ativas"""
    try:
        categories = Category.query.filter_by(is_active=True).all()
        
        return {
            'categories': [category.to_dict() for category in categories]
        }, 200
        
    except Exception as e:
        return {'error': f'Erro ao buscar categorias: {str(e)}'}, 500

@products_bp.route('/featured', methods=['GET'])
def get_featured_products():
    """Obter produtos em destaque"""
    try:
        limit = request.args.get('limit', 8, type=int)
        
        products = Product.query.filter_by(
            is_active=True,
            is_featured=True
        ).order_by(desc(Product.created_at)).limit(limit).all()
        
        return {
            'products': [product.to_dict() for product in products]
        }, 200
        
    except Exception as e:
        return {'error': f'Erro ao buscar produtos em destaque: {str(e)}'}, 500

@products_bp.route('/new', methods=['GET'])
def get_new_products():
    """Obter produtos novos"""
    try:
        limit = request.args.get('limit', 8, type=int)
        
        products = Product.query.filter_by(
            is_active=True,
            is_new=True
        ).order_by(desc(Product.created_at)).limit(limit).all()
        
        return {
            'products': [product.to_dict() for product in products]
        }, 200
        
    except Exception as e:
        return {'error': f'Erro ao buscar produtos novos: {str(e)}'}, 500

@products_bp.route('/sale', methods=['GET'])
def get_sale_products():
    """Obter produtos em promoção"""
    try:
        limit = request.args.get('limit', 8, type=int)
        
        products = Product.query.filter_by(
            is_active=True,
            is_on_sale=True
        ).order_by(desc(Product.created_at)).limit(limit).all()
        
        return {
            'products': [product.to_dict() for product in products]
        }, 200
        
    except Exception as e:
        return {'error': f'Erro ao buscar produtos em promoção: {str(e)}'}, 500

@products_bp.route('/search', methods=['GET'])
def search_products():
    """Buscar produtos por termo"""
    try:
        query_term = request.args.get('q', '').strip()
        
        if not query_term:
            return {'error': 'Termo de busca é obrigatório'}, 400
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 12, type=int)
        
        search_term = f"%{query_term}%"
        
        query = Product.query.filter(
            and_(
                Product.is_active == True,
                or_(
                    Product.name.ilike(search_term),
                    Product.description.ilike(search_term),
                    Product.short_description.ilike(search_term)
                )
            )
        ).order_by(desc(Product.created_at))
        
        pagination = query.paginate(
            page=page,
            per_page=per_page,
            error_out=False
        )
        
        products = pagination.items
        
        return {
            'products': [product.to_dict() for product in products],
            'search_term': query_term,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': pagination.total,
                'pages': pagination.pages,
                'has_next': pagination.has_next,
                'has_prev': pagination.has_prev
            }
        }, 200
        
    except Exception as e:
        return {'error': f'Erro ao buscar produtos: {str(e)}'}, 500

@products_bp.route('/<int:product_id>/variants', methods=['GET'])
def get_product_variants(product_id):
    """Obter variações de um produto"""
    try:
        product = Product.query.filter_by(id=product_id, is_active=True).first()
        
        if not product:
            return {'error': 'Produto não encontrado'}, 404
        
        variants = ProductVariant.query.filter_by(
            product_id=product_id,
            is_active=True
        ).all()
        
        return {
            'variants': [variant.to_dict() for variant in variants]
        }, 200
        
    except Exception as e:
        return {'error': f'Erro ao buscar variações: {str(e)}'}, 500

@products_bp.route('/filters', methods=['GET'])
def get_filter_options():
    """Obter opções disponíveis para filtros"""
    try:
        # Buscar categorias ativas
        categories = Category.query.filter_by(is_active=True).all()
        
        # Buscar tamanhos disponíveis
        sizes = db.session.query(ProductVariant.size).filter(
            ProductVariant.size.isnot(None),
            ProductVariant.is_active == True
        ).distinct().all()
        
        # Buscar faixa de preços
        price_range = db.session.query(
            db.func.min(Product.price).label('min_price'),
            db.func.max(Product.price).label('max_price')
        ).filter(Product.is_active == True).first()
        
        return {
            'categories': [category.to_dict() for category in categories],
            'sizes': [size[0] for size in sizes if size[0]],
            'price_range': {
                'min': float(price_range.min_price) if price_range.min_price else 0,
                'max': float(price_range.max_price) if price_range.max_price else 0
            }
        }, 200
        
    except Exception as e:
        return {'error': f'Erro ao buscar opções de filtro: {str(e)}'}, 500

