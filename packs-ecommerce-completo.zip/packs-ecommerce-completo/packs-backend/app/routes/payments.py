from flask import Blueprint, request, jsonify
from ..models import db, Order

payments_bp = Blueprint('payments', __name__)

@payments_bp.route('/methods', methods=['GET'])
def get_payment_methods():
    """Obter métodos de pagamento disponíveis"""
    try:
        methods = [
            {'id': 'credit_card', 'name': 'Cartão de Crédito', 'enabled': True},
            {'id': 'debit_card', 'name': 'Cartão de Débito', 'enabled': True},
            {'id': 'pix', 'name': 'PIX', 'enabled': True},
            {'id': 'boleto', 'name': 'Boleto Bancário', 'enabled': True},
            {'id': 'bank_transfer', 'name': 'Transferência Bancária', 'enabled': False}
        ]
        
        return {'payment_methods': methods}, 200
        
    except Exception as e:
        return {'error': f'Erro ao buscar métodos de pagamento: {str(e)}'}, 500

@payments_bp.route('/process', methods=['POST'])
def process_payment():
    """Processar pagamento"""
    try:
        data = request.get_json()
        
        # Validar dados obrigatórios
        if not data.get('order_id') or not data.get('payment_method'):
            return {'error': 'ID do pedido e método de pagamento são obrigatórios'}, 400
        
        order = Order.query.get(data['order_id'])
        if not order:
            return {'error': 'Pedido não encontrado'}, 404
        
        # Simular processamento de pagamento
        # Em produção, aqui seria integrado com gateway de pagamento
        
        return {
            'message': 'Pagamento processado com sucesso',
            'payment_id': f'PAY_{order.order_number}',
            'status': 'approved'
        }, 200
        
    except Exception as e:
        return {'error': f'Erro ao processar pagamento: {str(e)}'}, 500

