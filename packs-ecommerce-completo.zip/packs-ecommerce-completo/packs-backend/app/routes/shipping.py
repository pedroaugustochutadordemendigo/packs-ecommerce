from flask import Blueprint, request, jsonify

shipping_bp = Blueprint('shipping', __name__)

@shipping_bp.route('/calculate', methods=['POST'])
def calculate_shipping():
    """Calcular frete"""
    try:
        data = request.get_json()
        
        # Validar dados obrigatórios
        if not data.get('zipcode'):
            return {'error': 'CEP é obrigatório'}, 400
        
        zipcode = data['zipcode'].replace('-', '').replace('.', '')
        
        # Simular cálculo de frete
        # Em produção, aqui seria integrado com API dos Correios ou transportadora
        
        shipping_options = [
            {
                'id': 'pac',
                'name': 'PAC',
                'price': 15.90,
                'delivery_time': '5-7 dias úteis'
            },
            {
                'id': 'sedex',
                'name': 'SEDEX',
                'price': 25.90,
                'delivery_time': '2-3 dias úteis'
            }
        ]
        
        return {'shipping_options': shipping_options}, 200
        
    except Exception as e:
        return {'error': f'Erro ao calcular frete: {str(e)}'}, 500

@shipping_bp.route('/track/<string:tracking_code>', methods=['GET'])
def track_order(tracking_code):
    """Rastrear pedido"""
    try:
        # Simular rastreamento
        # Em produção, aqui seria integrado com API de rastreamento
        
        tracking_info = {
            'tracking_code': tracking_code,
            'status': 'Em trânsito',
            'events': [
                {'date': '2024-01-15', 'description': 'Objeto postado'},
                {'date': '2024-01-16', 'description': 'Objeto em trânsito'},
                {'date': '2024-01-17', 'description': 'Objeto saiu para entrega'}
            ]
        }
        
        return {'tracking': tracking_info}, 200
        
    except Exception as e:
        return {'error': f'Erro ao rastrear pedido: {str(e)}'}, 500

