def register_blueprints(app):
    """Registra todos os blueprints da aplicação"""
    
    from .auth import auth_bp
    from .products import products_bp
    from .cart import cart_bp
    from .orders import orders_bp
    from .admin import admin_bp
    from .payments import payments_bp
    from .shipping import shipping_bp
    from .social import social_bp
    
    # Registrar blueprints com prefixo /api
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(products_bp, url_prefix='/api/products')
    app.register_blueprint(cart_bp, url_prefix='/api/cart')
    app.register_blueprint(orders_bp, url_prefix='/api/orders')
    app.register_blueprint(admin_bp, url_prefix='/api/admin')
    app.register_blueprint(payments_bp, url_prefix='/api/payments')
    app.register_blueprint(shipping_bp, url_prefix='/api/shipping')
    app.register_blueprint(social_bp, url_prefix='/api/social')

