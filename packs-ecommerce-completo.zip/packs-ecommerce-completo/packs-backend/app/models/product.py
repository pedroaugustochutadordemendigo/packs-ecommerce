from . import db
from datetime import datetime

class Category(db.Model):
    __tablename__ = 'categories'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    slug = db.Column(db.String(100), unique=True, nullable=False, index=True)
    description = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamento com produtos
    products = db.relationship('Product', backref='category', lazy=True)
    
    def __repr__(self):
        return f'<Category {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'slug': self.slug,
            'description': self.description,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Product(db.Model):
    __tablename__ = 'products'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    slug = db.Column(db.String(200), unique=True, nullable=False, index=True)
    description = db.Column(db.Text)
    short_description = db.Column(db.String(500))
    
    # Preços
    price = db.Column(db.Numeric(10, 2), nullable=False)
    original_price = db.Column(db.Numeric(10, 2))
    cost_price = db.Column(db.Numeric(10, 2))
    
    # Categoria
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=False)
    
    # Estoque e disponibilidade
    stock_quantity = db.Column(db.Integer, default=0)
    min_stock = db.Column(db.Integer, default=5)
    is_active = db.Column(db.Boolean, default=True)
    is_featured = db.Column(db.Boolean, default=False)
    
    # Status especiais
    is_new = db.Column(db.Boolean, default=False)
    is_on_sale = db.Column(db.Boolean, default=False)
    
    # SEO
    meta_title = db.Column(db.String(200))
    meta_description = db.Column(db.String(500))
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    images = db.relationship('ProductImage', backref='product', lazy=True, cascade='all, delete-orphan')
    variants = db.relationship('ProductVariant', backref='product', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Product {self.name}>'
    
    @property
    def in_stock(self):
        return self.stock_quantity > 0
    
    @property
    def discount_percentage(self):
        if self.original_price and self.original_price > self.price:
            return round(((self.original_price - self.price) / self.original_price) * 100)
        return 0
    
    @property
    def primary_image(self):
        """Retorna a imagem principal do produto"""
        primary = next((img for img in self.images if img.is_primary), None)
        return primary or (self.images[0] if self.images else None)
    
    def to_dict(self, include_variants=True, include_images=True):
        data = {
            'id': self.id,
            'name': self.name,
            'slug': self.slug,
            'description': self.description,
            'short_description': self.short_description,
            'price': float(self.price),
            'original_price': float(self.original_price) if self.original_price else None,
            'category': self.category.to_dict() if self.category else None,
            'stock_quantity': self.stock_quantity,
            'in_stock': self.in_stock,
            'is_active': self.is_active,
            'is_featured': self.is_featured,
            'is_new': self.is_new,
            'is_on_sale': self.is_on_sale,
            'discount_percentage': self.discount_percentage,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
        
        if include_images:
            data['images'] = [img.to_dict() for img in self.images]
            data['primary_image'] = self.primary_image.to_dict() if self.primary_image else None
            
        if include_variants:
            data['variants'] = [variant.to_dict() for variant in self.variants]
            
        return data

class ProductImage(db.Model):
    __tablename__ = 'product_images'
    
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    image_url = db.Column(db.String(500), nullable=False)
    alt_text = db.Column(db.String(200))
    is_primary = db.Column(db.Boolean, default=False)
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<ProductImage {self.id} for Product {self.product_id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'image_url': self.image_url,
            'alt_text': self.alt_text,
            'is_primary': self.is_primary,
            'sort_order': self.sort_order
        }

class ProductVariant(db.Model):
    __tablename__ = 'product_variants'
    
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    
    # Variações (tamanho, cor, etc.)
    size = db.Column(db.String(50))
    color = db.Column(db.String(50))
    color_hex = db.Column(db.String(7))  # Código hexadecimal da cor
    
    # Estoque específico da variação
    stock_quantity = db.Column(db.Integer, default=0)
    
    # Preço específico (opcional)
    price_adjustment = db.Column(db.Numeric(10, 2), default=0)
    
    # SKU único
    sku = db.Column(db.String(100), unique=True, index=True)
    
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<ProductVariant {self.sku or self.id}>'
    
    @property
    def in_stock(self):
        return self.stock_quantity > 0
    
    def to_dict(self):
        return {
            'id': self.id,
            'size': self.size,
            'color': self.color,
            'color_hex': self.color_hex,
            'stock_quantity': self.stock_quantity,
            'in_stock': self.in_stock,
            'price_adjustment': float(self.price_adjustment) if self.price_adjustment else 0,
            'sku': self.sku,
            'is_active': self.is_active
        }

