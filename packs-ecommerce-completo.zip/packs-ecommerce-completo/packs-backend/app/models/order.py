from . import db
from datetime import datetime
from enum import Enum

class OrderStatus(Enum):
    PENDING = 'pending'
    CONFIRMED = 'confirmed'
    PROCESSING = 'processing'
    SHIPPED = 'shipped'
    DELIVERED = 'delivered'
    CANCELLED = 'cancelled'
    REFUNDED = 'refunded'

class PaymentStatus(Enum):
    PENDING = 'pending'
    APPROVED = 'approved'
    REJECTED = 'rejected'
    CANCELLED = 'cancelled'
    REFUNDED = 'refunded'

class PaymentMethod(Enum):
    CREDIT_CARD = 'credit_card'
    DEBIT_CARD = 'debit_card'
    PIX = 'pix'
    BOLETO = 'boleto'
    BANK_TRANSFER = 'bank_transfer'

class Order(db.Model):
    __tablename__ = 'orders'
    
    id = db.Column(db.Integer, primary_key=True)
    order_number = db.Column(db.String(50), unique=True, nullable=False, index=True)
    
    # Cliente
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    customer_email = db.Column(db.String(120), nullable=False)
    customer_name = db.Column(db.String(200), nullable=False)
    customer_phone = db.Column(db.String(20))
    customer_document = db.Column(db.String(20))  # CPF/CNPJ
    
    # Status
    status = db.Column(db.Enum(OrderStatus), default=OrderStatus.PENDING)
    payment_status = db.Column(db.Enum(PaymentStatus), default=PaymentStatus.PENDING)
    
    # Valores
    subtotal = db.Column(db.Numeric(10, 2), nullable=False)
    shipping_cost = db.Column(db.Numeric(10, 2), default=0)
    discount_amount = db.Column(db.Numeric(10, 2), default=0)
    total_amount = db.Column(db.Numeric(10, 2), nullable=False)
    
    # Cupom de desconto
    coupon_code = db.Column(db.String(50))
    
    # Endereço de entrega
    shipping_address_line1 = db.Column(db.String(200), nullable=False)
    shipping_address_line2 = db.Column(db.String(200))
    shipping_city = db.Column(db.String(100), nullable=False)
    shipping_state = db.Column(db.String(50), nullable=False)
    shipping_zipcode = db.Column(db.String(20), nullable=False)
    shipping_country = db.Column(db.String(50), default='Brasil')
    
    # Endereço de cobrança
    billing_address_line1 = db.Column(db.String(200))
    billing_address_line2 = db.Column(db.String(200))
    billing_city = db.Column(db.String(100))
    billing_state = db.Column(db.String(50))
    billing_zipcode = db.Column(db.String(20))
    billing_country = db.Column(db.String(50), default='Brasil')
    
    # Informações de envio
    shipping_method = db.Column(db.String(100))
    tracking_code = db.Column(db.String(100))
    estimated_delivery = db.Column(db.DateTime)
    delivered_at = db.Column(db.DateTime)
    
    # Pagamento
    payment_method = db.Column(db.Enum(PaymentMethod))
    payment_id = db.Column(db.String(100))  # ID do pagamento no gateway
    payment_data = db.Column(db.JSON)  # Dados adicionais do pagamento
    
    # Observações
    notes = db.Column(db.Text)
    admin_notes = db.Column(db.Text)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    items = db.relationship('OrderItem', backref='order', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Order {self.order_number}>'
    
    def generate_order_number(self):
        """Gera um número único para o pedido"""
        import random
        import string
        timestamp = datetime.now().strftime('%Y%m%d')
        random_part = ''.join(random.choices(string.digits, k=4))
        return f"PK{timestamp}{random_part}"
    
    @property
    def shipping_address(self):
        """Retorna o endereço de entrega formatado"""
        return {
            'line1': self.shipping_address_line1,
            'line2': self.shipping_address_line2,
            'city': self.shipping_city,
            'state': self.shipping_state,
            'zipcode': self.shipping_zipcode,
            'country': self.shipping_country
        }
    
    @property
    def billing_address(self):
        """Retorna o endereço de cobrança formatado"""
        return {
            'line1': self.billing_address_line1,
            'line2': self.billing_address_line2,
            'city': self.billing_city,
            'state': self.billing_state,
            'zipcode': self.billing_zipcode,
            'country': self.billing_country
        }
    
    def to_dict(self, include_items=True):
        data = {
            'id': self.id,
            'order_number': self.order_number,
            'customer_email': self.customer_email,
            'customer_name': self.customer_name,
            'customer_phone': self.customer_phone,
            'customer_document': self.customer_document,
            'status': self.status.value if self.status else None,
            'payment_status': self.payment_status.value if self.payment_status else None,
            'subtotal': float(self.subtotal),
            'shipping_cost': float(self.shipping_cost),
            'discount_amount': float(self.discount_amount),
            'total_amount': float(self.total_amount),
            'coupon_code': self.coupon_code,
            'shipping_address': self.shipping_address,
            'billing_address': self.billing_address,
            'shipping_method': self.shipping_method,
            'tracking_code': self.tracking_code,
            'estimated_delivery': self.estimated_delivery.isoformat() if self.estimated_delivery else None,
            'delivered_at': self.delivered_at.isoformat() if self.delivered_at else None,
            'payment_method': self.payment_method.value if self.payment_method else None,
            'payment_id': self.payment_id,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
        
        if include_items:
            data['items'] = [item.to_dict() for item in self.items]
            
        return data

class OrderItem(db.Model):
    __tablename__ = 'order_items'
    
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    variant_id = db.Column(db.Integer, db.ForeignKey('product_variants.id'))
    
    # Informações do produto no momento da compra
    product_name = db.Column(db.String(200), nullable=False)
    product_sku = db.Column(db.String(100))
    variant_info = db.Column(db.JSON)  # Tamanho, cor, etc.
    
    # Preços e quantidades
    unit_price = db.Column(db.Numeric(10, 2), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    total_price = db.Column(db.Numeric(10, 2), nullable=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    product = db.relationship('Product', backref='order_items')
    variant = db.relationship('ProductVariant', backref='order_items')
    
    def __repr__(self):
        return f'<OrderItem {self.id} - {self.product_name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'product_id': self.product_id,
            'product_name': self.product_name,
            'product_sku': self.product_sku,
            'variant_info': self.variant_info,
            'unit_price': float(self.unit_price),
            'quantity': self.quantity,
            'total_price': float(self.total_price),
            'product': self.product.to_dict(include_variants=False, include_images=False) if self.product else None,
            'variant': self.variant.to_dict() if self.variant else None
        }

class Cart(db.Model):
    __tablename__ = 'carts'
    
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.String(100), index=True)  # Para usuários não logados
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), index=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    items = db.relationship('CartItem', backref='cart', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Cart {self.id}>'
    
    @property
    def total_items(self):
        return sum(item.quantity for item in self.items)
    
    @property
    def total_amount(self):
        return sum(item.total_price for item in self.items)
    
    def add_item(self, product_id, quantity=1, variant_id=None):
        """Adiciona um item ao carrinho ou atualiza a quantidade"""
        existing_item = CartItem.query.filter_by(
            cart_id=self.id,
            product_id=product_id,
            variant_id=variant_id
        ).first()
        
        if existing_item:
            existing_item.quantity += quantity
            existing_item.updated_at = datetime.utcnow()
        else:
            from .product import Product
            product = Product.query.get(product_id)
            if product:
                new_item = CartItem(
                    cart_id=self.id,
                    product_id=product_id,
                    variant_id=variant_id,
                    quantity=quantity,
                    unit_price=product.price
                )
                db.session.add(new_item)
        
        self.updated_at = datetime.utcnow()
        db.session.commit()
    
    def remove_item(self, item_id):
        """Remove um item do carrinho"""
        item = CartItem.query.filter_by(id=item_id, cart_id=self.id).first()
        if item:
            db.session.delete(item)
            self.updated_at = datetime.utcnow()
            db.session.commit()
    
    def clear(self):
        """Limpa todos os itens do carrinho"""
        CartItem.query.filter_by(cart_id=self.id).delete()
        self.updated_at = datetime.utcnow()
        db.session.commit()
    
    def to_dict(self):
        return {
            'id': self.id,
            'total_items': self.total_items,
            'total_amount': float(self.total_amount),
            'items': [item.to_dict() for item in self.items],
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class CartItem(db.Model):
    __tablename__ = 'cart_items'
    
    id = db.Column(db.Integer, primary_key=True)
    cart_id = db.Column(db.Integer, db.ForeignKey('carts.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    variant_id = db.Column(db.Integer, db.ForeignKey('product_variants.id'))
    
    quantity = db.Column(db.Integer, nullable=False, default=1)
    unit_price = db.Column(db.Numeric(10, 2), nullable=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    product = db.relationship('Product', backref='cart_items')
    variant = db.relationship('ProductVariant', backref='cart_items')
    
    def __repr__(self):
        return f'<CartItem {self.id}>'
    
    @property
    def total_price(self):
        return self.unit_price * self.quantity
    
    def update_quantity(self, new_quantity):
        """Atualiza a quantidade do item"""
        if new_quantity <= 0:
            db.session.delete(self)
        else:
            self.quantity = new_quantity
            self.updated_at = datetime.utcnow()
        db.session.commit()
    
    def to_dict(self):
        return {
            'id': self.id,
            'product': self.product.to_dict(include_variants=False, include_images=True) if self.product else None,
            'variant': self.variant.to_dict() if self.variant else None,
            'quantity': self.quantity,
            'unit_price': float(self.unit_price),
            'total_price': float(self.total_price),
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

