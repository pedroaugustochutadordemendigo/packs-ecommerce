# Quick Start - PACKS E-commerce

⚡ **Guia de início rápido para começar em 5 minutos**

## 🚀 Início Ultra-Rápido

### 1️⃣ Extrair e Abrir (30 segundos)
```bash
# Extrair projeto
unzip packs-ecommerce-completo.zip
cd packs-ecommerce-completo

# Abrir no VS Code
code packs-ecommerce.code-workspace
```

### 2️⃣ Configurar Ambiente (2 minutos)
```bash
# Backend
cd packs-backend
./scripts/setup.sh

# Frontend  
cd ../packs-frontend
./scripts/setup.sh

# Voltar para raiz
cd ..
```

### 3️⃣ Executar Projeto (30 segundos)
```bash
# Executar ambos
./dev-full.sh
```

### 4️⃣ Acessar (Imediato)
- **Frontend**: http://localhost:5173
- **Backend**: http://localhost:5000

## ✨ Comandos VS Code

### Via Command Palette (Ctrl+Shift+P)
- `🚀 Start Full Development` - Iniciar tudo
- `🧪 Run Backend Tests` - Testar backend
- `🏗️ Build Frontend` - Build produção

### Via Terminal Integrado
```bash
# Terminal 1: Backend
cd packs-backend && python run.py

# Terminal 2: Frontend
cd packs-frontend && pnpm run dev

# Terminal 3: Git
git status
```

## 🐙 GitHub Setup (5 minutos)

### Criar Repositórios
1. **GitHub.com** → New Repository
2. **Nome**: `packs-backend`
3. **Descrição**: `🔧 PACKS E-commerce Backend`
4. **Repetir** para `packs-frontend`

### Configurar Localmente
```bash
# Backend
cd packs-backend
git init
git remote add origin https://github.com/SEU_USUARIO/packs-backend.git
git add .
git commit -m "🎉 Initial commit"
git push -u origin main

# Frontend
cd ../packs-frontend
git init
git remote add origin https://github.com/SEU_USUARIO/packs-frontend.git
git add .
git commit -m "🎉 Initial commit"
git push -u origin main
```

## 🎯 Estrutura Visual

```
📁 packs-ecommerce-completo/
├── 🔧 packs-backend/          # API Flask
├── 🎨 packs-frontend/         # Interface React
├── 📁 .vscode/               # Configurações VS Code
├── 📄 *.code-workspace       # Workspace
├── 📄 dev-full.sh           # Script desenvolvimento
└── 📄 README.md             # Documentação
```

## 🔧 Troubleshooting Rápido

### Backend não inicia
```bash
cd packs-backend
source venv/bin/activate
pip install -r requirements.txt
python run.py
```

### Frontend não inicia
```bash
cd packs-frontend
pnpm install
pnpm run dev
```

### VS Code não reconhece Python
```bash
# Ctrl+Shift+P → "Python: Select Interpreter"
# Escolher: ./packs-backend/venv/bin/python
```

## 📱 URLs Importantes

- **Frontend**: http://localhost:5173
- **Backend**: http://localhost:5000
- **API Health**: http://localhost:5000/api/health
- **API Docs**: http://localhost:5000/api/docs

## 🎨 Customização Rápida

### Cores (packs-frontend/src/App.css)
```css
:root {
  --primary: #00ff88;    /* Verde neon */
  --secondary: #000000;  /* Preto */
  --accent: #ffffff;     /* Branco */
}
```

### Logo (packs-frontend/public/)
- Substituir `favicon.ico`
- Adicionar `logo.png`

## 🚀 Deploy Rápido

### Frontend (Vercel)
```bash
cd packs-frontend
pnpm run build
# Upload dist/ para Vercel
```

### Backend (Heroku)
```bash
cd packs-backend
heroku create packs-backend
git push heroku main
```

## 📋 Checklist de Sucesso

- [ ] ✅ Projeto extraído
- [ ] ✅ VS Code aberto com workspace
- [ ] ✅ Backend rodando (localhost:5000)
- [ ] ✅ Frontend rodando (localhost:5173)
- [ ] ✅ Extensões VS Code instaladas
- [ ] ✅ Git configurado
- [ ] ✅ GitHub repositórios criados

## 🎉 Próximos Passos

1. **Personalizar** cores e logo
2. **Adicionar** produtos no backend
3. **Testar** funcionalidades
4. **Deploy** em produção
5. **Configurar** domínio personalizado

---

**Pronto para começar! 🚀**

Em caso de dúvidas, consulte:
- [README.md](README.md) - Documentação completa
- [VSCODE_SETUP_GUIDE.md](VSCODE_SETUP_GUIDE.md) - Guia VS Code
- [GITHUB_SETUP.md](GITHUB_SETUP.md) - Guia GitHub

