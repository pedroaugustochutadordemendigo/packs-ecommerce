# Guia de Integração - PACKS E-commerce

🔗 **Como configurar e executar os repositórios frontend e backend juntos**

Este guia explica como configurar e executar os repositórios separados do PACKS E-commerce de forma integrada.

## 📋 Visão Geral

O projeto PACKS E-commerce agora está dividido em dois repositórios independentes:

- **packs-backend** - API REST em Flask
- **packs-frontend** - Interface React

## 🚀 Configuração Inicial

### 1. Clonar os Repositórios

```bash
# Criar diretório do projeto
mkdir packs-ecommerce-full
cd packs-ecommerce-full

# Clonar backend
git clone https://github.com/packs-streetwear/packs-backend.git
cd packs-backend
./scripts/setup.sh
cd ..

# Clonar frontend
git clone https://github.com/packs-streetwear/packs-frontend.git
cd packs-frontend
./scripts/setup.sh
cd ..
```

### 2. Configurar Variáveis de Ambiente

#### Backend (.env)
```env
# packs-backend/.env
FLASK_ENV=development
FLASK_DEBUG=True
SECRET_KEY=your-super-secret-key
DATABASE_URL=sqlite:///database/packs.db
CORS_ORIGINS=http://localhost:5173,http://localhost:3000
JWT_SECRET_KEY=your-jwt-secret
```

#### Frontend (.env)
```env
# packs-frontend/.env
VITE_API_URL=http://localhost:5000/api
VITE_APP_URL=http://localhost:5173
VITE_DEV_MODE=true
```

## 🏃‍♂️ Executando os Serviços

### Opção 1: Execução Manual (Recomendada para Desenvolvimento)

#### Terminal 1 - Backend
```bash
cd packs-backend
source venv/bin/activate  # Linux/Mac
# ou venv\Scripts\activate  # Windows
python run.py
```

#### Terminal 2 - Frontend
```bash
cd packs-frontend
pnpm run dev
# ou npm run dev
# ou yarn dev
```

### Opção 2: Script de Desenvolvimento Conjunto

Crie um script `dev.sh` na raiz:

```bash
#!/bin/bash
# dev.sh

echo "🚀 Iniciando PACKS E-commerce..."

# Função para cleanup
cleanup() {
    echo "🛑 Parando servidores..."
    kill $(jobs -p) 2>/dev/null
    exit 0
}

trap cleanup SIGINT SIGTERM

# Iniciar backend
echo "🐍 Iniciando backend..."
cd packs-backend
source venv/bin/activate
python run.py &
BACKEND_PID=$!
cd ..

# Aguardar backend inicializar
sleep 3

# Iniciar frontend
echo "🎨 Iniciando frontend..."
cd packs-frontend
pnpm run dev --host &
FRONTEND_PID=$!
cd ..

echo ""
echo "✅ Servidores iniciados!"
echo "🌐 Frontend: http://localhost:5173"
echo "🔧 Backend:  http://localhost:5000"
echo ""
echo "💡 Pressione Ctrl+C para parar"

# Aguardar processos
wait
```

```bash
chmod +x dev.sh
./dev.sh
```

### Opção 3: Docker Compose (Produção)

Crie um `docker-compose.yml`:

```yaml
version: '3.8'

services:
  backend:
    build: ./packs-backend
    ports:
      - "5000:5000"
    environment:
      - FLASK_ENV=production
      - DATABASE_URL=sqlite:///database/packs.db
      - CORS_ORIGINS=http://localhost:3000
    volumes:
      - ./packs-backend/database:/app/database
    networks:
      - packs-network

  frontend:
    build: ./packs-frontend
    ports:
      - "3000:3000"
    environment:
      - VITE_API_URL=http://localhost:5000/api
    depends_on:
      - backend
    networks:
      - packs-network

networks:
  packs-network:
    driver: bridge
```

```bash
docker-compose up -d
```

## 🔧 Configuração de Desenvolvimento

### VS Code Workspace

Crie um arquivo `packs-ecommerce.code-workspace`:

```json
{
  "folders": [
    {
      "name": "Backend",
      "path": "./packs-backend"
    },
    {
      "name": "Frontend", 
      "path": "./packs-frontend"
    }
  ],
  "settings": {
    "python.defaultInterpreterPath": "./packs-backend/venv/bin/python",
    "eslint.workingDirectories": ["packs-frontend"],
    "editor.formatOnSave": true
  },
  "extensions": {
    "recommendations": [
      "ms-python.python",
      "ms-python.flake8",
      "bradlc.vscode-tailwindcss",
      "esbenp.prettier-vscode",
      "ms-vscode.vscode-eslint"
    ]
  }
}
```

### Git Hooks (Opcional)

Para manter consistência entre os repositórios:

```bash
# .githooks/pre-commit
#!/bin/bash

echo "🔍 Verificando backend..."
cd packs-backend
source venv/bin/activate
black app/ --check
flake8 app/
cd ..

echo "🔍 Verificando frontend..."
cd packs-frontend
pnpm run lint
cd ..

echo "✅ Verificações concluídas"
```

## 🌐 URLs e Endpoints

### Desenvolvimento
- **Frontend**: http://localhost:5173
- **Backend**: http://localhost:5000
- **API Docs**: http://localhost:5000/api/docs (se implementado)
- **Health Check**: http://localhost:5000/api/health

### Produção
- **Frontend**: https://packs.com.br
- **Backend**: https://api.packs.com.br
- **API**: https://api.packs.com.br/api

## 🔄 Fluxo de Desenvolvimento

### 1. Desenvolvimento de Features

```bash
# Backend
cd packs-backend
git checkout -b feature/nova-api
# Desenvolver API
git commit -am "Adiciona nova API"
git push origin feature/nova-api

# Frontend
cd packs-frontend
git checkout -b feature/nova-interface
# Desenvolver interface
git commit -am "Adiciona nova interface"
git push origin feature/nova-interface
```

### 2. Sincronização de Mudanças

```bash
# Atualizar backend
cd packs-backend
git pull origin main

# Atualizar frontend
cd packs-frontend
git pull origin main
```

### 3. Testes de Integração

```bash
# Testar backend
cd packs-backend
pytest

# Testar frontend
cd packs-frontend
pnpm run test

# Teste manual de integração
curl http://localhost:5000/api/health
# Verificar frontend em http://localhost:5173
```

## 🚀 Deploy

### Deploy Separado

#### Backend (Heroku)
```bash
cd packs-backend
heroku create packs-backend-api
git push heroku main
```

#### Frontend (Vercel/Netlify)
```bash
cd packs-frontend
# Configurar VITE_API_URL para produção
npm run build
# Deploy via interface web ou CLI
```

### Deploy Conjunto (VPS)

```bash
# Script de deploy
#!/bin/bash

echo "🚀 Deploy PACKS E-commerce..."

# Build frontend
cd packs-frontend
npm run build
cd ..

# Copiar build para backend
cp -r packs-frontend/dist/* packs-backend/static/

# Deploy backend
cd packs-backend
gunicorn -w 4 -b 0.0.0.0:5000 "app:create_app()"
```

## 🔍 Troubleshooting

### Problemas Comuns

#### CORS Error
```bash
# Verificar CORS_ORIGINS no backend
# Verificar VITE_API_URL no frontend
```

#### Backend não conecta
```bash
# Verificar se backend está rodando
curl http://localhost:5000/api/health

# Verificar logs
cd packs-backend
tail -f logs/app.log
```

#### Frontend não carrega
```bash
# Verificar dependências
cd packs-frontend
pnpm install

# Verificar variáveis de ambiente
cat .env
```

### Logs e Debug

#### Backend
```bash
cd packs-backend
tail -f logs/app.log
```

#### Frontend
```bash
# Console do navegador (F12)
# Ou logs do Vite no terminal
```

## 📚 Documentação Adicional

- [Backend README](packs-backend/README.md)
- [Frontend README](packs-frontend/README.md)
- [API Documentation](packs-backend/docs/api.md)
- [Component Documentation](packs-frontend/docs/components.md)

## 🤝 Contribuição

1. Fork ambos os repositórios
2. Crie branches para suas features
3. Mantenha sincronização entre mudanças
4. Teste integração antes do PR
5. Documente mudanças na API

## 📞 Suporte

- **Email**: packsorganization@gmail.com
- **Issues Backend**: [GitHub Issues Backend](https://github.com/packs-streetwear/packs-backend/issues)
- **Issues Frontend**: [GitHub Issues Frontend](https://github.com/packs-streetwear/packs-frontend/issues)

---

**PACKS Streetwear** - Arquitetura moderna para streetwear autêntico.

