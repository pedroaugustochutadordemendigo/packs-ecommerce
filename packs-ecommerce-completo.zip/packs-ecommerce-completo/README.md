# PACKS E-commerce - Projeto Completo

🚀 **E-commerce completo de streetwear com arquitetura moderna e profissional**

## 🎯 Início Rápido

### 1️⃣ Abrir no VS Code
```bash
# Extrair o projeto
unzip packs-ecommerce-completo.zip
cd packs-ecommerce-completo

# Abrir workspace no VS Code
code packs-ecommerce.code-workspace
```

### 2️⃣ Configurar Ambiente
```bash
# Backend
cd packs-backend
./scripts/setup.sh

# Frontend
cd ../packs-frontend
./scripts/setup.sh

# Voltar para raiz
cd ..
```

### 3️⃣ Executar Projeto
```bash
# Executar ambos (backend + frontend)
./dev-full.sh

# OU executar separadamente:
# Terminal 1: cd packs-backend && python run.py
# Terminal 2: cd packs-frontend && pnpm run dev
```

### 4️⃣ Acessar Aplicação
- **Frontend**: http://localhost:5173
- **Backend**: http://localhost:5000
- **API Health**: http://localhost:5000/api/health

## 📁 Estrutura do Projeto

```
packs-ecommerce-completo/
├── 📁 packs-backend/              # 🔧 API Flask
│   ├── app/                       # Código principal
│   ├── tests/                     # Testes automatizados
│   ├── docs/                      # Documentação
│   ├── scripts/                   # Scripts utilitários
│   ├── requirements*.txt          # Dependências
│   ├── Dockerfile                 # Container Docker
│   └── README.md                  # Docs do backend
├── 📁 packs-frontend/             # 🎨 Interface React
│   ├── src/                       # Código fonte
│   ├── public/                    # Arquivos estáticos
│   ├── docs/                      # Documentação
│   ├── scripts/                   # Scripts utilitários
│   ├── package.json               # Dependências Node
│   └── README.md                  # Docs do frontend
├── 📁 .vscode/                    # Configurações VS Code
│   ├── settings.json              # Configurações
│   ├── extensions.json            # Extensões recomendadas
│   ├── tasks.json                 # Tarefas
│   └── launch.json                # Debug configs
├── 📄 packs-ecommerce.code-workspace  # Workspace VS Code
├── 📄 dev-full.sh                 # Script desenvolvimento
├── 📄 INTEGRATION_GUIDE.md        # Guia de integração
├── 📄 VSCODE_SETUP_GUIDE.md       # Guia VS Code
├── 📄 GITHUB_SETUP.md             # Guia GitHub
└── 📄 README.md                   # Este arquivo
```

## 🛠️ Tecnologias

### Backend (Flask)
- **Python 3.11+** - Linguagem principal
- **Flask** - Framework web
- **SQLAlchemy** - ORM para banco de dados
- **Marshmallow** - Serialização e validação
- **JWT** - Autenticação
- **pytest** - Testes automatizados

### Frontend (React)
- **React 18** - Biblioteca UI
- **Vite** - Build tool moderna
- **Tailwind CSS** - Framework CSS
- **shadcn/ui** - Componentes UI
- **React Router** - Roteamento
- **Axios** - Cliente HTTP

## 🎨 VS Code - Configuração Completa

### Workspace Configurado
- ✅ **Multi-root workspace** com backend e frontend
- ✅ **Configurações específicas** para Python e React
- ✅ **Tarefas automatizadas** para desenvolvimento
- ✅ **Debug configurado** para ambos projetos
- ✅ **Extensões recomendadas** instaladas automaticamente

### Comandos Disponíveis (Ctrl+Shift+P)
- `🚀 Start Full Development` - Iniciar ambos serviços
- `🔧 Start Backend Only` - Apenas backend
- `🎨 Start Frontend Only` - Apenas frontend
- `🧪 Run Backend Tests` - Testes do backend
- `🧪 Run Frontend Tests` - Testes do frontend
- `🏗️ Build Frontend` - Build de produção

### Debug Configurado
- **Backend**: Debug Python com breakpoints
- **Frontend**: Debug React com source maps
- **Testes**: Debug de testes unitários

## 🐙 GitHub - Setup Completo

### Repositórios Separados
```bash
# Criar repositórios no GitHub
# 1. packs-backend
# 2. packs-frontend

# Configurar backend
cd packs-backend
git init
git remote add origin https://github.com/SEU_USUARIO/packs-backend.git
git add .
git commit -m "🎉 Initial commit - Backend Flask"
git push -u origin main

# Configurar frontend
cd ../packs-frontend
git init
git remote add origin https://github.com/SEU_USUARIO/packs-frontend.git
git add .
git commit -m "🎉 Initial commit - Frontend React"
git push -u origin main
```

### CI/CD Configurado
- ✅ **GitHub Actions** para testes automatizados
- ✅ **Deploy automático** configurado
- ✅ **Code quality** checks
- ✅ **Security scanning**

## 🚀 Deploy

### Desenvolvimento Local
```bash
./dev-full.sh
```

### Produção
```bash
# Backend
cd packs-backend
docker build -t packs-backend .
docker run -p 5000:5000 packs-backend

# Frontend
cd packs-frontend
pnpm run build
# Deploy para Vercel/Netlify
```

## 📚 Documentação

- **[Backend README](packs-backend/README.md)** - Documentação completa do backend
- **[Frontend README](packs-frontend/README.md)** - Documentação completa do frontend
- **[Guia de Integração](INTEGRATION_GUIDE.md)** - Como usar os repositórios juntos
- **[Guia VS Code](VSCODE_SETUP_GUIDE.md)** - Configuração detalhada do VS Code
- **[Guia GitHub](GITHUB_SETUP.md)** - Configuração de repositórios

## 🎯 Funcionalidades

### E-commerce Completo
- ✅ **Catálogo de produtos** com filtros e busca
- ✅ **Carrinho de compras** persistente
- ✅ **Sistema de usuários** com autenticação
- ✅ **Checkout completo** com múltiplas formas de pagamento
- ✅ **Painel administrativo** para gestão
- ✅ **Integração com redes sociais**

### Recursos Técnicos
- ✅ **API REST completa** com documentação
- ✅ **Interface responsiva** para todos dispositivos
- ✅ **Testes automatizados** com alta cobertura
- ✅ **Docker** pronto para produção
- ✅ **CI/CD** configurado
- ✅ **Monitoramento** e logs

## 🔧 Comandos Úteis

### Desenvolvimento
```bash
# Iniciar desenvolvimento
./dev-full.sh

# Executar testes
cd packs-backend && pytest
cd packs-frontend && pnpm test

# Build de produção
cd packs-frontend && pnpm run build

# Linting e formatação
cd packs-backend && black app/ && flake8 app/
cd packs-frontend && pnpm run lint && pnpm run format
```

### Git
```bash
# Status de ambos repositórios
git -C packs-backend status
git -C packs-frontend status

# Commit em ambos
git -C packs-backend add . && git -C packs-backend commit -m "Update backend"
git -C packs-frontend add . && git -C packs-frontend commit -m "Update frontend"

# Push em ambos
git -C packs-backend push
git -C packs-frontend push
```

## 🎨 Customização

### Cores e Tema
- **Primária**: #00ff88 (Verde neon)
- **Secundária**: #000000 (Preto)
- **Accent**: #ffffff (Branco)

### Tipografia
- **Headings**: Inter Bold
- **Body**: Inter Regular
- **Code**: JetBrains Mono

## 🤝 Contribuição

1. Fork os repositórios
2. Crie uma branch para sua feature
3. Faça suas alterações
4. Execute os testes
5. Faça commit das mudanças
6. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 📞 Suporte

- **Email**: packsorganization@gmail.com
- **Issues Backend**: [GitHub Issues Backend](https://github.com/SEU_USUARIO/packs-backend/issues)
- **Issues Frontend**: [GitHub Issues Frontend](https://github.com/SEU_USUARIO/packs-frontend/issues)

---

**PACKS Streetwear** - Streetwear autêntico para quem não passa despercebido.

## 🎉 Próximos Passos

1. ✅ **Extrair o projeto**
2. ✅ **Abrir no VS Code** (`code packs-ecommerce.code-workspace`)
3. ✅ **Executar setup** (scripts automáticos)
4. ✅ **Iniciar desenvolvimento** (`./dev-full.sh`)
5. ✅ **Configurar GitHub** (repositórios separados)
6. ✅ **Deploy em produção**

**Tudo pronto para começar! 🚀**

