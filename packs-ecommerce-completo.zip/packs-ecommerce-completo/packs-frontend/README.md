# PACKS Frontend

🎨 **Interface moderna e responsiva para o e-commerce de streetwear PACKS**

Uma aplicação React moderna construída com Vite, Tailwind CSS e as melhores práticas de desenvolvimento frontend.

## 📋 Índice

- [Tecnologias](#-tecnologias)
- [Instalação](#-instalação)
- [Configuração](#-configuração)
- [Execução](#-execução)
- [Estrutura do Projeto](#-estrutura-do-projeto)
- [Componentes](#-componentes)
- [Desenvolvimento](#-desenvolvimento)
- [Build e Deploy](#-build-e-deploy)
- [Testes](#-testes)

## 🛠️ Tecnologias

- **React 18** - Biblioteca JavaScript para interfaces
- **Vite** - Build tool e dev server
- **Tailwind CSS** - Framework CSS utilitário
- **shadcn/ui** - Componentes UI modernos
- **Lucide React** - Ícones SVG
- **React Router** - Roteamento
- **Framer Motion** - Animações
- **Recharts** - Gráficos e visualizações

## 🚀 Instalação

### Pré-requisitos

- Node.js 16+ 
- npm, yarn ou pnpm

### Clonando o Repositório

```bash
git clone https://github.com/packs-streetwear/packs-frontend.git
cd packs-frontend
```

### Instalação de Dependências

```bash
# Com pnpm (recomendado)
pnpm install

# Com npm
npm install

# Com yarn
yarn install
```

## ⚙️ Configuração

1. **Criar arquivo de ambiente:**
```bash
cp .env.example .env
```

2. **Configurar variáveis no arquivo `.env`:**
```env
# URL da API do backend
VITE_API_URL=http://localhost:5000/api

# URL base da aplicação
VITE_APP_URL=http://localhost:5173

# Configurações de desenvolvimento
VITE_DEV_MODE=true

# Configurações de analytics (opcional)
VITE_GOOGLE_ANALYTICS_ID=

# Configurações de pagamento (opcional)
VITE_STRIPE_PUBLIC_KEY=

# Configurações de mapas (opcional)
VITE_GOOGLE_MAPS_API_KEY=
```

## 🏃‍♂️ Execução

### Desenvolvimento
```bash
pnpm run dev
# ou
npm run dev
```

### Build de Produção
```bash
pnpm run build
# ou
npm run build
```

### Preview do Build
```bash
pnpm run preview
# ou
npm run preview
```

## 📁 Estrutura do Projeto

```
packs-frontend/
├── public/                  # Arquivos estáticos
│   ├── favicon.ico
│   └── og-image.jpg
├── src/                     # Código fonte
│   ├── assets/             # Assets (imagens, ícones)
│   ├── components/         # Componentes React
│   │   ├── ui/            # Componentes UI base (shadcn/ui)
│   │   ├── Header.jsx     # Cabeçalho da aplicação
│   │   ├── Footer.jsx     # Rodapé da aplicação
│   │   ├── HeroBanner.jsx # Banner principal
│   │   └── ProductGrid.jsx # Grid de produtos
│   ├── pages/             # Páginas da aplicação
│   │   ├── Home.jsx       # Página inicial
│   │   ├── Products.jsx   # Página de produtos
│   │   ├── Product.jsx    # Página de produto individual
│   │   ├── Cart.jsx       # Página do carrinho
│   │   └── Checkout.jsx   # Página de checkout
│   ├── services/          # Serviços e APIs
│   │   ├── api.js         # Configuração da API
│   │   ├── auth.js        # Serviços de autenticação
│   │   └── products.js    # Serviços de produtos
│   ├── contexts/          # Contextos React
│   │   ├── AuthContext.jsx # Contexto de autenticação
│   │   └── CartContext.jsx # Contexto do carrinho
│   ├── hooks/             # Custom hooks
│   │   ├── useAuth.js     # Hook de autenticação
│   │   └── useCart.js     # Hook do carrinho
│   ├── utils/             # Utilitários
│   │   ├── helpers.js     # Funções auxiliares
│   │   └── validators.js  # Validadores
│   ├── constants/         # Constantes
│   │   └── index.js       # Constantes da aplicação
│   ├── lib/               # Configurações de bibliotecas
│   │   └── utils.js       # Utilitários do shadcn/ui
│   ├── App.jsx            # Componente principal
│   ├── App.css            # Estilos principais
│   ├── index.css          # Estilos globais
│   └── main.jsx           # Ponto de entrada
├── docs/                  # Documentação
│   ├── components.md      # Documentação dos componentes
│   ├── deployment.md      # Guia de deploy
│   └── development.md     # Guia de desenvolvimento
├── scripts/               # Scripts utilitários
│   ├── build.sh          # Script de build
│   └── deploy.sh         # Script de deploy
├── .env.example          # Exemplo de variáveis de ambiente
├── .gitignore            # Arquivos ignorados pelo Git
├── components.json       # Configuração do shadcn/ui
├── eslint.config.js      # Configuração do ESLint
├── index.html            # Template HTML
├── package.json          # Dependências e scripts
├── pnpm-lock.yaml        # Lock file do pnpm
├── tailwind.config.js    # Configuração do Tailwind
├── vite.config.js        # Configuração do Vite
└── README.md             # Este arquivo
```

## 🧩 Componentes

### Componentes Principais

- **Header** - Navegação principal com menu responsivo
- **HeroBanner** - Banner principal com slider
- **ProductGrid** - Grid de produtos com filtros
- **Footer** - Rodapé com links e newsletter

### Componentes UI (shadcn/ui)

- **Button** - Botões customizáveis
- **Input** - Campos de entrada
- **Card** - Cards para conteúdo
- **Dialog** - Modais e diálogos
- **Dropdown** - Menus dropdown

## 🎨 Desenvolvimento

### Estrutura de Estilos

```css
/* Estilos globais */
@import "tailwindcss";
@import "tw-animate-css";

/* Estilos customizados do PACKS */
.logo-packs { /* Logo styling */ }
.glass-effect { /* Glass morphism */ }
.gradient-primary { /* Gradiente principal */ }
.btn-primary { /* Botão primário */ }
.product-card { /* Card de produto */ }
```

### Padrões de Código

- **Componentes funcionais** com hooks
- **Props tipadas** com PropTypes ou TypeScript
- **Nomes descritivos** para componentes e funções
- **Estrutura consistente** de arquivos

### Comandos de Desenvolvimento

```bash
# Iniciar servidor de desenvolvimento
pnpm run dev

# Verificar linting
pnpm run lint

# Corrigir problemas de linting
pnpm run lint:fix

# Formatar código
pnpm run format
```

## 🏗️ Build e Deploy

### Build Local
```bash
pnpm run build
```

### Deploy Automático
```bash
# Usando o script de deploy
./scripts/deploy.sh
```

### Variáveis de Produção
```env
VITE_API_URL=https://api.packs.com.br/api
VITE_APP_URL=https://packs.com.br
VITE_DEV_MODE=false
```

## 🧪 Testes

### Executar Testes
```bash
# Testes unitários
pnpm run test

# Testes com watch mode
pnpm run test:watch

# Cobertura de testes
pnpm run test:coverage
```

### Estrutura de Testes
```
src/
├── components/
│   ├── Header.jsx
│   └── __tests__/
│       └── Header.test.jsx
```

## 📱 Responsividade

O projeto é totalmente responsivo com breakpoints:

- **Mobile**: < 768px
- **Tablet**: 768px - 1024px  
- **Desktop**: > 1024px

## 🎯 Performance

### Otimizações Implementadas

- **Code splitting** automático
- **Lazy loading** de componentes
- **Otimização de imagens**
- **Minificação** de CSS e JS
- **Tree shaking** automático

### Métricas Alvo

- **First Contentful Paint**: < 1.5s
- **Largest Contentful Paint**: < 2.5s
- **Cumulative Layout Shift**: < 0.1

## 🔧 Configurações

### Tailwind CSS
Configurado com tema customizado do PACKS:
- Cores da marca
- Tipografia personalizada
- Componentes utilitários

### Vite
Configurado com:
- Hot Module Replacement
- Otimizações de build
- Plugins essenciais

### ESLint
Regras configuradas para:
- React best practices
- Hooks rules
- Accessibility

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/nova-feature`)
3. Commit suas mudanças (`git commit -am 'Adiciona nova feature'`)
4. Push para a branch (`git push origin feature/nova-feature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 📞 Suporte

- **Email:** packsorganization@gmail.com
- **Documentação:** [docs/](docs/)
- **Issues:** [GitHub Issues](https://github.com/packs-streetwear/packs-frontend/issues)

---

**PACKS Streetwear** - Streetwear autêntico para quem não passa despercebido.

