import { useState, useEffect } from 'react'
import { Heart, ShoppingCart, Eye, Star } from 'lucide-react'
import { Button } from '@/components/ui/button'

const ProductGrid = () => {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')

  // Mock products data
  const mockProducts = [
    {
      id: 1,
      name: "Camiseta Streetwear Classic",
      price: 89.90,
      originalPrice: 119.90,
      image: "/api/placeholder/300/400",
      category: "camisetas",
      isNew: true,
      isOnSale: true,
      rating: 4.8,
      colors: ["#000000", "#FFFFFF", "#FF0000"]
    },
    {
      id: 2,
      name: "Hoodie Urban Style",
      price: 159.90,
      originalPrice: null,
      image: "/api/placeholder/300/400",
      category: "hoodies",
      isNew: false,
      isOnSale: false,
      rating: 4.9,
      colors: ["#000000", "#808080"]
    },
    {
      id: 3,
      name: "Jaqueta Bomber Premium",
      price: 249.90,
      originalPrice: 299.90,
      image: "/api/placeholder/300/400",
      category: "jaquetas",
      isNew: true,
      isOnSale: true,
      rating: 4.7,
      colors: ["#000000", "#008000"]
    },
    {
      id: 4,
      name: "Calça Cargo Street",
      price: 139.90,
      originalPrice: null,
      image: "/api/placeholder/300/400",
      category: "calcas",
      isNew: false,
      isOnSale: false,
      rating: 4.6,
      colors: ["#000000", "#8B4513", "#808080"]
    },
    {
      id: 5,
      name: "Boné Snapback PACKS",
      price: 69.90,
      originalPrice: 89.90,
      image: "/api/placeholder/300/400",
      category: "acessorios",
      isNew: true,
      isOnSale: true,
      rating: 4.8,
      colors: ["#000000", "#FFFFFF"]
    },
    {
      id: 6,
      name: "Tênis High Top",
      price: 199.90,
      originalPrice: null,
      image: "/api/placeholder/300/400",
      category: "calcados",
      isNew: false,
      isOnSale: false,
      rating: 4.9,
      colors: ["#000000", "#FFFFFF", "#FF0000"]
    }
  ]

  const categories = [
    { id: 'all', name: 'Todos' },
    { id: 'camisetas', name: 'Camisetas' },
    { id: 'hoodies', name: 'Hoodies' },
    { id: 'jaquetas', name: 'Jaquetas' },
    { id: 'calcas', name: 'Calças' },
    { id: 'acessorios', name: 'Acessórios' },
    { id: 'calcados', name: 'Calçados' }
  ]

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setProducts(mockProducts)
      setLoading(false)
    }, 1000)
  }, [])

  const filteredProducts = filter === 'all' 
    ? products 
    : products.filter(product => product.category === filter)

  const ProductCard = ({ product }) => (
    <div className="product-card group">
      {/* Image Container */}
      <div className="relative overflow-hidden aspect-[3/4]">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {product.isNew && (
            <span className="badge badge-new">NOVO</span>
          )}
          {product.isOnSale && (
            <span className="badge badge-sale">
              -{Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}%
            </span>
          )}
        </div>

        {/* Actions */}
        <div className="absolute top-3 right-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <Button
            size="icon"
            variant="secondary"
            className="h-8 w-8 bg-white/90 hover:bg-white text-black"
          >
            <Heart className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="secondary"
            className="h-8 w-8 bg-white/90 hover:bg-white text-black"
          >
            <Eye className="h-4 w-4" />
          </Button>
        </div>

        {/* Quick Add to Cart */}
        <div className="absolute bottom-3 left-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <Button className="w-full btn-primary">
            <ShoppingCart className="mr-2 h-4 w-4" />
            Adicionar ao Carrinho
          </Button>
        </div>
      </div>

      {/* Product Info */}
      <div className="p-4">
        <h3 className="font-semibold text-white mb-2 line-clamp-2">
          {product.name}
        </h3>
        
        {/* Rating */}
        <div className="flex items-center gap-1 mb-2">
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`h-3 w-3 ${
                  i < Math.floor(product.rating)
                    ? 'text-yellow-400 fill-current'
                    : 'text-gray-400'
                }`}
              />
            ))}
          </div>
          <span className="text-xs text-gray-400">({product.rating})</span>
        </div>

        {/* Colors */}
        <div className="flex gap-1 mb-3">
          {product.colors.map((color, index) => (
            <div
              key={index}
              className="w-4 h-4 rounded-full border border-white/20"
              style={{ backgroundColor: color }}
            />
          ))}
        </div>

        {/* Price */}
        <div className="flex items-center gap-2">
          <span className="text-green-500 font-bold text-lg">
            R$ {product.price.toFixed(2)}
          </span>
          {product.originalPrice && (
            <span className="text-gray-400 line-through text-sm">
              R$ {product.originalPrice.toFixed(2)}
            </span>
          )}
        </div>
      </div>
    </div>
  )

  return (
    <section id="produtos" className="py-20 bg-black">
      <div className="container-custom">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Nossa <span className="text-gradient">Coleção</span>
          </h2>
          <p className="text-xl text-white/80 max-w-2xl mx-auto">
            Descubra peças únicas que definem o streetwear autêntico
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={filter === category.id ? "default" : "outline"}
              onClick={() => setFilter(category.id)}
              className={
                filter === category.id
                  ? "btn-primary"
                  : "btn-secondary"
              }
            >
              {category.name}
            </Button>
          ))}
        </div>

        {/* Products Grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, index) => (
              <div key={index} className="product-card animate-pulse">
                <div className="aspect-[3/4] bg-gray-700 rounded-lg mb-4" />
                <div className="p-4">
                  <div className="h-4 bg-gray-700 rounded mb-2" />
                  <div className="h-3 bg-gray-700 rounded w-2/3 mb-2" />
                  <div className="h-4 bg-gray-700 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}

        {/* Load More */}
        {!loading && (
          <div className="text-center mt-12">
            <Button className="btn-secondary text-lg px-8 py-4">
              Carregar Mais Produtos
            </Button>
          </div>
        )}
      </div>
    </section>
  )
}

export default ProductGrid

