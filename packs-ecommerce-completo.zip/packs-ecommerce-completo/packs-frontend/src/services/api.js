/**
 * API Service - Configuração e métodos para comunicação com o backend
 */

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'
const API_TIMEOUT = import.meta.env.VITE_API_TIMEOUT || 10000

/**
 * Configuração base para requisições
 */
const defaultConfig = {
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: API_TIMEOUT,
}

/**
 * Interceptor para adicionar token de autenticação
 */
const addAuthToken = (config = {}) => {
  const token = localStorage.getItem('auth_token')
  if (token) {
    config.headers = {
      ...config.headers,
      'Authorization': `Bearer ${token}`,
    }
  }
  return config
}

/**
 * Wrapper para fetch com configurações padrão
 */
const apiRequest = async (endpoint, options = {}) => {
  const url = `${API_BASE_URL}${endpoint}`
  const config = {
    ...defaultConfig,
    ...options,
    headers: {
      ...defaultConfig.headers,
      ...options.headers,
    },
  }

  // Adicionar token de autenticação se disponível
  const configWithAuth = addAuthToken(config)

  try {
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), config.timeout)

    const response = await fetch(url, {
      ...configWithAuth,
      signal: controller.signal,
    })

    clearTimeout(timeoutId)

    // Verificar se a resposta é JSON
    const contentType = response.headers.get('content-type')
    const isJson = contentType && contentType.includes('application/json')

    const data = isJson ? await response.json() : await response.text()

    if (!response.ok) {
      throw new Error(data.message || `HTTP error! status: ${response.status}`)
    }

    return data
  } catch (error) {
    if (error.name === 'AbortError') {
      throw new Error('Request timeout')
    }
    throw error
  }
}

/**
 * Métodos HTTP
 */
export const api = {
  /**
   * GET request
   */
  get: (endpoint, params = {}) => {
    const queryString = new URLSearchParams(params).toString()
    const url = queryString ? `${endpoint}?${queryString}` : endpoint
    return apiRequest(url, { method: 'GET' })
  },

  /**
   * POST request
   */
  post: (endpoint, data = {}) => {
    return apiRequest(endpoint, {
      method: 'POST',
      body: JSON.stringify(data),
    })
  },

  /**
   * PUT request
   */
  put: (endpoint, data = {}) => {
    return apiRequest(endpoint, {
      method: 'PUT',
      body: JSON.stringify(data),
    })
  },

  /**
   * PATCH request
   */
  patch: (endpoint, data = {}) => {
    return apiRequest(endpoint, {
      method: 'PATCH',
      body: JSON.stringify(data),
    })
  },

  /**
   * DELETE request
   */
  delete: (endpoint) => {
    return apiRequest(endpoint, { method: 'DELETE' })
  },

  /**
   * Upload de arquivo
   */
  upload: (endpoint, formData) => {
    const config = addAuthToken({
      method: 'POST',
      body: formData,
      // Não definir Content-Type para FormData (o browser define automaticamente)
    })

    return fetch(`${API_BASE_URL}${endpoint}`, config)
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }
        return response.json()
      })
  },
}

/**
 * Interceptors para tratamento de erros globais
 */
export const setupApiInterceptors = () => {
  // Interceptor para logout automático em caso de token expirado
  const originalRequest = api.get
  api.get = async (...args) => {
    try {
      return await originalRequest.apply(api, args)
    } catch (error) {
      if (error.message.includes('401') || error.message.includes('Unauthorized')) {
        localStorage.removeItem('auth_token')
        window.location.href = '/login'
      }
      throw error
    }
  }
}

/**
 * Health check da API
 */
export const checkApiHealth = async () => {
  try {
    const response = await api.get('/health')
    return response.status === 'ok'
  } catch (error) {
    console.error('API health check failed:', error)
    return false
  }
}

/**
 * Configurar base URL dinamicamente
 */
export const setApiBaseUrl = (url) => {
  API_BASE_URL = url
}

export default api

