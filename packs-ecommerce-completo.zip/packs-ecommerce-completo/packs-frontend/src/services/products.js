/**
 * Products Service - Serviços relacionados a produtos
 */

import { api } from './api.js'

/**
 * Buscar todos os produtos com filtros opcionais
 */
export const getProducts = async (filters = {}) => {
  try {
    const params = {
      page: filters.page || 1,
      limit: filters.limit || 12,
      category: filters.category || '',
      search: filters.search || '',
      sort: filters.sort || 'created_at',
      order: filters.order || 'desc',
      min_price: filters.minPrice || '',
      max_price: filters.maxPrice || '',
      in_stock: filters.inStock || '',
    }

    // Remover parâmetros vazios
    Object.keys(params).forEach(key => {
      if (params[key] === '' || params[key] === null || params[key] === undefined) {
        delete params[key]
      }
    })

    const response = await api.get('/products', params)
    return response
  } catch (error) {
    console.error('Erro ao buscar produtos:', error)
    throw new Error('Não foi possível carregar os produtos')
  }
}

/**
 * Buscar produto por ID
 */
export const getProductById = async (id) => {
  try {
    const response = await api.get(`/products/${id}`)
    return response
  } catch (error) {
    console.error('Erro ao buscar produto:', error)
    throw new Error('Produto não encontrado')
  }
}

/**
 * Buscar produtos em destaque
 */
export const getFeaturedProducts = async (limit = 8) => {
  try {
    const response = await api.get('/products/featured', { limit })
    return response
  } catch (error) {
    console.error('Erro ao buscar produtos em destaque:', error)
    throw new Error('Não foi possível carregar os produtos em destaque')
  }
}

/**
 * Buscar produtos relacionados
 */
export const getRelatedProducts = async (productId, limit = 4) => {
  try {
    const response = await api.get(`/products/${productId}/related`, { limit })
    return response
  } catch (error) {
    console.error('Erro ao buscar produtos relacionados:', error)
    return []
  }
}

/**
 * Buscar categorias de produtos
 */
export const getCategories = async () => {
  try {
    const response = await api.get('/products/categories')
    return response
  } catch (error) {
    console.error('Erro ao buscar categorias:', error)
    throw new Error('Não foi possível carregar as categorias')
  }
}

/**
 * Buscar produtos por categoria
 */
export const getProductsByCategory = async (category, filters = {}) => {
  try {
    const params = {
      ...filters,
      category,
    }
    return await getProducts(params)
  } catch (error) {
    console.error('Erro ao buscar produtos por categoria:', error)
    throw new Error('Não foi possível carregar os produtos da categoria')
  }
}

/**
 * Buscar produtos com desconto
 */
export const getProductsOnSale = async (filters = {}) => {
  try {
    const params = {
      ...filters,
      on_sale: true,
    }
    const response = await api.get('/products', params)
    return response
  } catch (error) {
    console.error('Erro ao buscar produtos em promoção:', error)
    throw new Error('Não foi possível carregar os produtos em promoção')
  }
}

/**
 * Buscar produtos por termo de pesquisa
 */
export const searchProducts = async (query, filters = {}) => {
  try {
    const params = {
      ...filters,
      search: query,
    }
    return await getProducts(params)
  } catch (error) {
    console.error('Erro ao pesquisar produtos:', error)
    throw new Error('Não foi possível realizar a pesquisa')
  }
}

/**
 * Obter sugestões de pesquisa
 */
export const getSearchSuggestions = async (query) => {
  try {
    const response = await api.get('/products/search/suggestions', { q: query })
    return response
  } catch (error) {
    console.error('Erro ao buscar sugestões:', error)
    return []
  }
}

/**
 * Avaliar produto
 */
export const rateProduct = async (productId, rating, comment = '') => {
  try {
    const response = await api.post(`/products/${productId}/rate`, {
      rating,
      comment,
    })
    return response
  } catch (error) {
    console.error('Erro ao avaliar produto:', error)
    throw new Error('Não foi possível enviar a avaliação')
  }
}

/**
 * Obter avaliações do produto
 */
export const getProductReviews = async (productId, page = 1, limit = 10) => {
  try {
    const response = await api.get(`/products/${productId}/reviews`, {
      page,
      limit,
    })
    return response
  } catch (error) {
    console.error('Erro ao buscar avaliações:', error)
    return { reviews: [], total: 0 }
  }
}

/**
 * Verificar disponibilidade do produto
 */
export const checkProductAvailability = async (productId, size = null, color = null) => {
  try {
    const params = {}
    if (size) params.size = size
    if (color) params.color = color

    const response = await api.get(`/products/${productId}/availability`, params)
    return response
  } catch (error) {
    console.error('Erro ao verificar disponibilidade:', error)
    return { available: false, stock: 0 }
  }
}

/**
 * Obter variações do produto (tamanhos, cores)
 */
export const getProductVariations = async (productId) => {
  try {
    const response = await api.get(`/products/${productId}/variations`)
    return response
  } catch (error) {
    console.error('Erro ao buscar variações:', error)
    return { sizes: [], colors: [] }
  }
}

/**
 * Adicionar produto à lista de desejos
 */
export const addToWishlist = async (productId) => {
  try {
    const response = await api.post('/wishlist/add', { product_id: productId })
    return response
  } catch (error) {
    console.error('Erro ao adicionar à lista de desejos:', error)
    throw new Error('Não foi possível adicionar à lista de desejos')
  }
}

/**
 * Remover produto da lista de desejos
 */
export const removeFromWishlist = async (productId) => {
  try {
    const response = await api.delete(`/wishlist/remove/${productId}`)
    return response
  } catch (error) {
    console.error('Erro ao remover da lista de desejos:', error)
    throw new Error('Não foi possível remover da lista de desejos')
  }
}

/**
 * Obter lista de desejos do usuário
 */
export const getWishlist = async () => {
  try {
    const response = await api.get('/wishlist')
    return response
  } catch (error) {
    console.error('Erro ao buscar lista de desejos:', error)
    return []
  }
}

