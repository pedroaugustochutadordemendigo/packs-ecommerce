#!/bin/bash

# PACKS Frontend Setup Script
echo "🎨 Configurando PACKS Frontend..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js não está instalado. Por favor, instale Node.js 16+ primeiro."
    exit 1
fi

# Check Node.js version
node_version=$(node --version | cut -d'v' -f2)
required_version="16.0.0"

if [ "$(printf '%s\n' "$required_version" "$node_version" | sort -V | head -n1)" != "$required_version" ]; then
    echo "❌ Node.js 16+ é necessário. Versão atual: $node_version"
    exit 1
fi

echo "✅ Node.js $node_version encontrado"

# Check for package managers
if command -v pnpm &> /dev/null; then
    PACKAGE_MANAGER="pnpm"
    echo "✅ Usando pnpm como gerenciador de pacotes"
elif command -v yarn &> /dev/null; then
    PACKAGE_MANAGER="yarn"
    echo "✅ Usando yarn como gerenciador de pacotes"
elif command -v npm &> /dev/null; then
    PACKAGE_MANAGER="npm"
    echo "✅ Usando npm como gerenciador de pacotes"
else
    echo "❌ Nenhum gerenciador de pacotes encontrado (npm, yarn, pnpm)"
    exit 1
fi

# Install dependencies
echo "📦 Instalando dependências..."
case $PACKAGE_MANAGER in
    "pnpm")
        pnpm install
        ;;
    "yarn")
        yarn install
        ;;
    "npm")
        npm install
        ;;
esac

if [ $? -ne 0 ]; then
    echo "❌ Erro ao instalar dependências"
    exit 1
fi

echo "✅ Dependências instaladas com sucesso"

# Create .env file if it doesn't exist
if [ ! -f ".env" ]; then
    echo "⚙️ Criando arquivo .env..."
    cp .env.example .env
    echo "📝 Por favor, configure as variáveis no arquivo .env"
else
    echo "✅ Arquivo .env já existe"
fi

# Create necessary directories
mkdir -p src/assets/images
mkdir -p src/assets/icons
mkdir -p public/images

echo "📁 Diretórios criados"

# Check if backend is running
echo "🔍 Verificando conexão com o backend..."
backend_url=$(grep VITE_API_URL .env 2>/dev/null | cut -d'=' -f2 | tr -d '"' | tr -d "'")
if [ -z "$backend_url" ]; then
    backend_url="http://localhost:5000/api"
fi

if curl -s "${backend_url}/health" > /dev/null 2>&1; then
    echo "✅ Backend está rodando e acessível"
else
    echo "⚠️ Backend não está acessível em $backend_url"
    echo "   Certifique-se de que o backend está rodando antes de iniciar o frontend"
fi

echo ""
echo "✅ Setup concluído!"
echo ""
echo "📋 Próximos passos:"
echo "1. Configure as variáveis de ambiente no arquivo .env"
echo "2. Certifique-se de que o backend está rodando"
echo "3. Execute um dos comandos abaixo para iniciar:"
echo ""
echo "🔗 Comandos disponíveis:"
case $PACKAGE_MANAGER in
    "pnpm")
        echo "  pnpm run dev        - Iniciar servidor de desenvolvimento"
        echo "  pnpm run build      - Build de produção"
        echo "  pnpm run preview    - Preview do build"
        echo "  pnpm run lint       - Verificar código"
        ;;
    "yarn")
        echo "  yarn dev            - Iniciar servidor de desenvolvimento"
        echo "  yarn build          - Build de produção"
        echo "  yarn preview        - Preview do build"
        echo "  yarn lint           - Verificar código"
        ;;
    "npm")
        echo "  npm run dev         - Iniciar servidor de desenvolvimento"
        echo "  npm run build       - Build de produção"
        echo "  npm run preview     - Preview do build"
        echo "  npm run lint        - Verificar código"
        ;;
esac
echo ""
echo "🌐 URLs importantes:"
echo "  Frontend: http://localhost:5173"
echo "  Backend:  $backend_url"
echo ""
echo "📚 Documentação:"
echo "  README.md           - Documentação principal"
echo "  docs/               - Documentação detalhada"

