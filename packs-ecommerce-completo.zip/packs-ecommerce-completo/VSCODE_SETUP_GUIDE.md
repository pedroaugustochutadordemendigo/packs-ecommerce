# VS Code Setup - PACKS E-commerce

🎨 **Como configurar o VS Code para trabalhar com os repositórios separados**

## 📁 Estrutura de Pastas Recomendada

```
📁 packs-ecommerce/                    # Pasta principal do projeto
├── 📁 packs-backend/                  # Repositório do backend
│   ├── 📁 app/
│   │   ├── 📁 models/
│   │   ├── 📁 routes/
│   │   ├── 📁 schemas/
│   │   ├── 📁 services/
│   │   └── 📁 utils/
│   ├── 📁 tests/
│   ├── 📁 docs/
│   ├── 📁 scripts/
│   ├── 📄 requirements.txt
│   ├── 📄 requirements-dev.txt
│   ├── 📄 requirements-prod.txt
│   ├── 📄 Dockerfile
│   ├── 📄 run.py
│   └── 📄 README.md
├── 📁 packs-frontend/                 # Repositório do frontend
│   ├── 📁 src/
│   │   ├── 📁 components/
│   │   ├── 📁 pages/
│   │   ├── 📁 services/
│   │   ├── 📁 contexts/
│   │   ├── 📁 hooks/
│   │   ├── 📁 utils/
│   │   └── 📁 constants/
│   ├── 📁 public/
│   ├── 📁 docs/
│   ├── 📁 scripts/
│   ├── 📄 package.json
│   ├── 📄 vite.config.js
│   ├── 📄 tailwind.config.js
│   └── 📄 README.md
├── 📄 packs-ecommerce.code-workspace  # Workspace do VS Code
├── 📄 INTEGRATION_GUIDE.md
├── 📄 dev-full.sh
└── 📄 README.md
```

## ⚙️ Configuração do Workspace

### 1. Criar Workspace File

Crie o arquivo `packs-ecommerce.code-workspace`:

```json
{
  "folders": [
    {
      "name": "🔧 Backend (Flask)",
      "path": "./packs-backend"
    },
    {
      "name": "🎨 Frontend (React)",
      "path": "./packs-frontend"
    },
    {
      "name": "📚 Documentação",
      "path": "."
    }
  ],
  "settings": {
    // Python (Backend)
    "python.defaultInterpreterPath": "./packs-backend/venv/bin/python",
    "python.terminal.activateEnvironment": true,
    "python.linting.enabled": true,
    "python.linting.flake8Enabled": true,
    "python.linting.pylintEnabled": false,
    "python.formatting.provider": "black",
    "python.formatting.blackArgs": ["--line-length=88"],
    
    // JavaScript/React (Frontend)
    "typescript.preferences.importModuleSpecifier": "relative",
    "javascript.preferences.importModuleSpecifier": "relative",
    "emmet.includeLanguages": {
      "javascript": "javascriptreact"
    },
    
    // ESLint
    "eslint.workingDirectories": [
      "./packs-frontend"
    ],
    "eslint.validate": [
      "javascript",
      "javascriptreact",
      "typescript",
      "typescriptreact"
    ],
    
    // Formatação
    "editor.formatOnSave": true,
    "editor.codeActionsOnSave": {
      "source.fixAll.eslint": true,
      "source.organizeImports": true
    },
    
    // Tailwind CSS
    "tailwindCSS.includeLanguages": {
      "javascript": "javascript",
      "html": "HTML"
    },
    "tailwindCSS.experimental.classRegex": [
      "class[Name]*\\s*[:=]\\s*[\"']([^\"']*)[\"']",
      "className\\s*[:=]\\s*[\"']([^\"']*)[\"']"
    ],
    
    // Arquivos
    "files.exclude": {
      "**/node_modules": true,
      "**/venv": true,
      "**/__pycache__": true,
      "**/dist": true,
      "**/.git": true
    },
    
    // Terminal
    "terminal.integrated.cwd": ".",
    "terminal.integrated.defaultProfile.linux": "bash",
    "terminal.integrated.defaultProfile.osx": "zsh",
    
    // Git
    "git.ignoreLimitWarning": true,
    "git.autofetch": true,
    
    // Outros
    "editor.tabSize": 2,
    "editor.insertSpaces": true,
    "editor.detectIndentation": false,
    "files.trimTrailingWhitespace": true,
    "files.insertFinalNewline": true
  },
  "extensions": {
    "recommendations": [
      // Python (Backend)
      "ms-python.python",
      "ms-python.flake8",
      "ms-python.black-formatter",
      "ms-python.isort",
      
      // JavaScript/React (Frontend)
      "esbenp.prettier-vscode",
      "ms-vscode.vscode-eslint",
      "bradlc.vscode-tailwindcss",
      "formulahendry.auto-rename-tag",
      "christian-kohler.path-intellisense",
      
      // Git
      "eamodio.gitlens",
      "github.vscode-pull-request-github",
      
      // Utilitários
      "ms-vscode.vscode-json",
      "redhat.vscode-yaml",
      "ms-vscode.vscode-markdown",
      "yzhang.markdown-all-in-one",
      "shd101wyy.markdown-preview-enhanced",
      
      // Docker
      "ms-azuretools.vscode-docker",
      
      // REST Client
      "humao.rest-client",
      
      // Outros
      "ms-vscode.vscode-thunder-client",
      "ms-vscode.vscode-todo-highlight",
      "gruntfuggly.todo-tree"
    ]
  },
  "tasks": {
    "version": "2.0.0",
    "tasks": [
      {
        "label": "🚀 Start Full Development",
        "type": "shell",
        "command": "./dev-full.sh",
        "group": "build",
        "presentation": {
          "echo": true,
          "reveal": "always",
          "focus": false,
          "panel": "new"
        },
        "problemMatcher": []
      },
      {
        "label": "🔧 Start Backend Only",
        "type": "shell",
        "command": "python run.py",
        "options": {
          "cwd": "${workspaceFolder}/packs-backend"
        },
        "group": "build",
        "presentation": {
          "echo": true,
          "reveal": "always",
          "focus": false,
          "panel": "new"
        }
      },
      {
        "label": "🎨 Start Frontend Only",
        "type": "shell",
        "command": "pnpm run dev",
        "options": {
          "cwd": "${workspaceFolder}/packs-frontend"
        },
        "group": "build",
        "presentation": {
          "echo": true,
          "reveal": "always",
          "focus": false,
          "panel": "new"
        }
      },
      {
        "label": "🧪 Run Backend Tests",
        "type": "shell",
        "command": "pytest",
        "options": {
          "cwd": "${workspaceFolder}/packs-backend"
        },
        "group": "test"
      },
      {
        "label": "🧪 Run Frontend Tests",
        "type": "shell",
        "command": "pnpm run test",
        "options": {
          "cwd": "${workspaceFolder}/packs-frontend"
        },
        "group": "test"
      },
      {
        "label": "🏗️ Build Frontend",
        "type": "shell",
        "command": "pnpm run build",
        "options": {
          "cwd": "${workspaceFolder}/packs-frontend"
        },
        "group": "build"
      }
    ]
  },
  "launch": {
    "version": "0.2.0",
    "configurations": [
      {
        "name": "🔧 Debug Backend",
        "type": "python",
        "request": "launch",
        "program": "${workspaceFolder}/packs-backend/run.py",
        "console": "integratedTerminal",
        "cwd": "${workspaceFolder}/packs-backend",
        "env": {
          "FLASK_ENV": "development",
          "FLASK_DEBUG": "1"
        }
      },
      {
        "name": "🎨 Debug Frontend",
        "type": "node",
        "request": "launch",
        "program": "${workspaceFolder}/packs-frontend/node_modules/.bin/vite",
        "args": ["--mode", "development"],
        "cwd": "${workspaceFolder}/packs-frontend",
        "console": "integratedTerminal"
      }
    ]
  }
}
```

## 🎯 Como Abrir no VS Code

### Opção 1: Via Workspace (Recomendado)
```bash
# Navegar para a pasta principal
cd packs-ecommerce

# Abrir workspace
code packs-ecommerce.code-workspace
```

### Opção 2: Via Linha de Comando
```bash
# Abrir pasta principal
code packs-ecommerce/
```

## 📋 Interface do VS Code

### Sidebar - Explorer
```
📁 PACKS-ECOMMERCE
├── 📁 🔧 BACKEND (FLASK)
│   ├── 📁 app
│   │   ├── 📁 models
│   │   │   ├── 📄 __init__.py
│   │   │   ├── 📄 user.py
│   │   │   ├── 📄 product.py
│   │   │   └── 📄 order.py
│   │   ├── 📁 routes
│   │   │   ├── 📄 __init__.py
│   │   │   ├── 📄 auth.py
│   │   │   ├── 📄 products.py
│   │   │   └── 📄 cart.py
│   │   └── 📄 __init__.py
│   ├── 📁 tests
│   ├── 📄 requirements.txt
│   ├── 📄 run.py
│   └── 📄 README.md
├── 📁 🎨 FRONTEND (REACT)
│   ├── 📁 src
│   │   ├── 📁 components
│   │   │   ├── 📄 Header.jsx
│   │   │   ├── 📄 Footer.jsx
│   │   │   └── 📄 ProductGrid.jsx
│   │   ├── 📁 pages
│   │   ├── 📁 services
│   │   │   ├── 📄 api.js
│   │   │   └── 📄 products.js
│   │   └── 📄 App.jsx
│   ├── 📄 package.json
│   ├── 📄 vite.config.js
│   └── 📄 README.md
└── 📁 📚 DOCUMENTAÇÃO
    ├── 📄 INTEGRATION_GUIDE.md
    ├── 📄 dev-full.sh
    └── 📄 README.md
```

## 🔧 Configurações por Arquivo

### .vscode/settings.json (Local)
```json
{
  "python.defaultInterpreterPath": "./packs-backend/venv/bin/python",
  "eslint.workingDirectories": ["./packs-frontend"],
  "tailwindCSS.includeLanguages": {
    "javascript": "javascript"
  }
}
```

### .vscode/extensions.json
```json
{
  "recommendations": [
    "ms-python.python",
    "ms-python.flake8",
    "esbenp.prettier-vscode",
    "ms-vscode.vscode-eslint",
    "bradlc.vscode-tailwindcss",
    "eamodio.gitlens"
  ]
}
```

## 🚀 Comandos Rápidos (Ctrl+Shift+P)

### Tarefas Disponíveis
- `🚀 Start Full Development` - Iniciar frontend + backend
- `🔧 Start Backend Only` - Apenas backend
- `🎨 Start Frontend Only` - Apenas frontend
- `🧪 Run Backend Tests` - Testes do backend
- `🧪 Run Frontend Tests` - Testes do frontend
- `🏗️ Build Frontend` - Build de produção

### Debug Configurations
- `🔧 Debug Backend` - Debug do Flask
- `🎨 Debug Frontend` - Debug do React

## 📱 Layout Recomendado

### Configuração de Painéis
```
┌─────────────────────────────────────────────────────────────┐
│ 📁 Explorer    │           Editor Principal                  │
│ ├── Backend    │  ┌─────────────────────────────────────┐   │
│ ├── Frontend   │  │         Código Atual                │   │
│ └── Docs       │  │                                     │   │
│                │  └─────────────────────────────────────┘   │
│ 🔍 Search      │  ┌─────────────────────────────────────┐   │
│                │  │         Terminal                    │   │
│ 📊 Git         │  │  Backend: python run.py            │   │
│                │  │  Frontend: pnpm run dev             │   │
│ 🐛 Debug       │  └─────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

## 🎨 Temas e Aparência Recomendados

### Temas
- **Dark**: One Dark Pro, Dracula, Material Theme
- **Light**: Light+, Solarized Light

### Ícones
- **Material Icon Theme** - Para melhor visualização de arquivos
- **VSCode Icons** - Alternativa popular

## ⌨️ Atalhos Úteis

### Navegação
- `Ctrl+P` - Buscar arquivos
- `Ctrl+Shift+P` - Paleta de comandos
- `Ctrl+Shift+E` - Explorer
- `Ctrl+Shift+F` - Busca global
- `Ctrl+Shift+G` - Git
- `Ctrl+Shift+D` - Debug

### Desenvolvimento
- `F5` - Iniciar debug
- `Ctrl+F5` - Executar sem debug
- `Ctrl+Shift+\`` - Novo terminal
- `Ctrl+J` - Toggle terminal
- `Ctrl+B` - Toggle sidebar

### Multi-cursor
- `Alt+Click` - Adicionar cursor
- `Ctrl+Alt+↑/↓` - Cursor acima/abaixo
- `Ctrl+D` - Selecionar próxima ocorrência

## 🔧 Terminal Integrado

### Configuração de Terminais
```bash
# Terminal 1: Backend
cd packs-backend
source venv/bin/activate
python run.py

# Terminal 2: Frontend  
cd packs-frontend
pnpm run dev

# Terminal 3: Git/Comandos gerais
git status
```

## 📊 Git Integration

### Configuração Multi-Repo
```bash
# Configurar Git para cada repositório
cd packs-backend
git init
git remote add origin https://github.com/user/packs-backend.git

cd ../packs-frontend  
git init
git remote add origin https://github.com/user/packs-frontend.git
```

### GitLens Configuration
```json
{
  "gitlens.views.repositories.files.layout": "tree",
  "gitlens.currentLine.enabled": true,
  "gitlens.codeLens.enabled": true
}
```

## 🧪 Testing Integration

### Test Explorer
- Configurar Python Test Discovery para backend
- Configurar Jest/Vitest para frontend
- Executar testes com cobertura

## 📝 Snippets Úteis

### Python (Backend)
```json
{
  "Flask Route": {
    "prefix": "froute",
    "body": [
      "@bp.route('/$1', methods=['$2'])",
      "def $3():",
      "    \"\"\"$4\"\"\"",
      "    try:",
      "        $5",
      "        return jsonify({'success': True})",
      "    except Exception as e:",
      "        return jsonify({'error': str(e)}), 400"
    ]
  }
}
```

### React (Frontend)
```json
{
  "React Component": {
    "prefix": "rfc",
    "body": [
      "import React from 'react'",
      "",
      "const $1 = () => {",
      "  return (",
      "    <div>",
      "      $2",
      "    </div>",
      "  )",
      "}",
      "",
      "export default $1"
    ]
  }
}
```

## 🎯 Workflow Recomendado

### 1. Abertura Diária
```bash
# Abrir workspace
code packs-ecommerce.code-workspace

# Executar desenvolvimento conjunto
Ctrl+Shift+P → "🚀 Start Full Development"
```

### 2. Desenvolvimento
- **Backend**: Editar em `packs-backend/app/`
- **Frontend**: Editar em `packs-frontend/src/`
- **Hot reload** ativo em ambos

### 3. Testes
```bash
# Backend
Ctrl+Shift+P → "🧪 Run Backend Tests"

# Frontend  
Ctrl+Shift+P → "🧪 Run Frontend Tests"
```

### 4. Commit
- Usar GitLens para commits separados
- Backend e Frontend têm histórico independente

Esta configuração proporciona uma experiência de desenvolvimento profissional e eficiente! 🚀

