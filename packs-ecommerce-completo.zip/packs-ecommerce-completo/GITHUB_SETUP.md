# GitHub Setup - PACKS E-commerce

🐙 **Guia completo para configurar os repositórios no GitHub**

## 🎯 Estratégia de Repositórios

### Repositórios Separados (Recomendado)
- **packs-backend** - API Flask
- **packs-frontend** - Interface React

### Vantagens
- ✅ **Versionamento independente**
- ✅ **Deploy separado**
- ✅ **Times especializados**
- ✅ **CI/CD otimizado**

## 🚀 Setup Inicial

### 1️⃣ Criar Repositórios no GitHub

#### Backend Repository
```bash
# No GitHub, criar repositório: packs-backend
# Descrição: "🔧 PACKS E-commerce - API Flask com arquitetura moderna"
# Público/Privado conforme necessário
# Adicionar README, .gitignore (Python), License (MIT)
```

#### Frontend Repository
```bash
# No GitHub, criar repositório: packs-frontend
# Descrição: "🎨 PACKS E-commerce - Interface React moderna e responsiva"
# Público/Privado conforme necessário
# Adicionar README, .gitignore (Node), License (MIT)
```

### 2️⃣ Configurar Repositório Backend

```bash
cd packs-backend

# Inicializar Git
git init

# Configurar remote
git remote add origin https://github.com/SEU_USUARIO/packs-backend.git

# Configurar branch principal
git branch -M main

# Primeiro commit
git add .
git commit -m "🎉 Initial commit - Backend Flask

✨ Features:
- Estrutura MVC profissional
- API REST completa
- Autenticação JWT
- Testes automatizados
- Docker configurado
- Documentação completa

🛠️ Tech Stack:
- Python 3.11+
- Flask
- SQLAlchemy
- Marshmallow
- pytest"

# Push inicial
git push -u origin main
```

### 3️⃣ Configurar Repositório Frontend

```bash
cd ../packs-frontend

# Inicializar Git
git init

# Configurar remote
git remote add origin https://github.com/SEU_USUARIO/packs-frontend.git

# Configurar branch principal
git branch -M main

# Primeiro commit
git add .
git commit -m "🎉 Initial commit - Frontend React

✨ Features:
- React 18 moderno
- Tailwind CSS + shadcn/ui
- Componentes reutilizáveis
- Integração completa com API
- Responsivo e acessível
- Build otimizado

🛠️ Tech Stack:
- React 18
- Vite
- Tailwind CSS
- shadcn/ui
- React Router"

# Push inicial
git push -u origin main
```

## 🔧 Configurações dos Repositórios

### Backend Repository Settings

#### About Section
```
🔧 PACKS E-commerce Backend

API Flask moderna com arquitetura MVC, autenticação JWT, 
testes automatizados e Docker configurado.

Website: https://packs-backend.herokuapp.com
Topics: flask, python, api, ecommerce, streetwear, mvc, jwt
```

#### Branch Protection Rules
```bash
# Configurar em: Settings > Branches > Add rule

Branch name pattern: main

✅ Require a pull request before merging
✅ Require status checks to pass before merging
  - ✅ Require branches to be up to date before merging
  - Status checks: tests, lint, security-scan
✅ Require conversation resolution before merging
✅ Include administrators
```

### Frontend Repository Settings

#### About Section
```
🎨 PACKS E-commerce Frontend

Interface React moderna e responsiva com Tailwind CSS, 
componentes reutilizáveis e integração completa com API.

Website: https://packs-frontend.vercel.app
Topics: react, vite, tailwindcss, frontend, ecommerce, streetwear, ui
```

#### Branch Protection Rules
```bash
# Configurar em: Settings > Branches > Add rule

Branch name pattern: main

✅ Require a pull request before merging
✅ Require status checks to pass before merging
  - ✅ Require branches to be up to date before merging
  - Status checks: build, lint, test
✅ Require conversation resolution before merging
✅ Include administrators
```

## 🔄 GitHub Actions (CI/CD)

### Backend CI/CD (.github/workflows/backend.yml)

```yaml
name: 🔧 Backend CI/CD

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: [3.9, 3.10, 3.11]

    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v3
      with:
        python-version: ${{ matrix.python-version }}
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements-dev.txt
    
    - name: Lint with flake8
      run: |
        flake8 app/ --count --select=E9,F63,F7,F82 --show-source --statistics
        flake8 app/ --count --exit-zero --max-complexity=10 --max-line-length=88 --statistics
    
    - name: Format with black
      run: |
        black app/ --check
    
    - name: Test with pytest
      run: |
        pytest tests/ -v --cov=app --cov-report=xml
    
    - name: Upload coverage to Codecov
      uses: codecov/codecov-action@v3
      with:
        file: ./coverage.xml

  security:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Run security scan
      uses: pypa/gh-action-pip-audit@v1.0.8

  deploy:
    needs: [test, security]
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Deploy to Heroku
      uses: akhileshns/heroku-deploy@v3.12.12
      with:
        heroku_api_key: ${{secrets.HEROKU_API_KEY}}
        heroku_app_name: "packs-backend"
        heroku_email: "seu-email@gmail.com"
```

### Frontend CI/CD (.github/workflows/frontend.yml)

```yaml
name: 🎨 Frontend CI/CD

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    
    strategy:
      matrix:
        node-version: [16.x, 18.x, 20.x]

    steps:
    - uses: actions/checkout@v3
    
    - name: Use Node.js ${{ matrix.node-version }}
      uses: actions/setup-node@v3
      with:
        node-version: ${{ matrix.node-version }}
        cache: 'pnpm'
    
    - name: Install pnpm
      uses: pnpm/action-setup@v2
      with:
        version: 8
    
    - name: Install dependencies
      run: pnpm install
    
    - name: Lint
      run: pnpm run lint
    
    - name: Type check
      run: pnpm run type-check
    
    - name: Test
      run: pnpm run test
    
    - name: Build
      run: pnpm run build

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Deploy to Vercel
      uses: amondnet/vercel-action@v20
      with:
        vercel-token: ${{ secrets.VERCEL_TOKEN }}
        vercel-org-id: ${{ secrets.ORG_ID }}
        vercel-project-id: ${{ secrets.PROJECT_ID }}
        vercel-args: '--prod'
```

## 📋 Issues Templates

### Backend Bug Report (.github/ISSUE_TEMPLATE/backend-bug.md)

```markdown
---
name: 🐛 Backend Bug Report
about: Reportar um bug na API
title: '[BUG] '
labels: bug, backend
assignees: ''
---

## 🐛 Descrição do Bug
Descrição clara e concisa do bug.

## 🔄 Reprodução
Passos para reproduzir:
1. Fazer requisição para '...'
2. Com os dados '...'
3. Ver erro

## ✅ Comportamento Esperado
O que deveria acontecer.

## 📱 Ambiente
- OS: [e.g. Ubuntu 20.04]
- Python: [e.g. 3.11]
- Flask: [e.g. 2.3.0]

## 📎 Logs
```
Cole os logs aqui
```

## 📋 Contexto Adicional
Qualquer outra informação relevante.
```

### Frontend Bug Report (.github/ISSUE_TEMPLATE/frontend-bug.md)

```markdown
---
name: 🎨 Frontend Bug Report
about: Reportar um bug na interface
title: '[BUG] '
labels: bug, frontend
assignees: ''
---

## 🐛 Descrição do Bug
Descrição clara e concisa do bug.

## 🔄 Reprodução
Passos para reproduzir:
1. Ir para '...'
2. Clicar em '...'
3. Ver erro

## ✅ Comportamento Esperado
O que deveria acontecer.

## 📱 Ambiente
- OS: [e.g. Windows 10]
- Browser: [e.g. Chrome 91]
- Device: [e.g. Desktop, Mobile]

## 📸 Screenshots
Se aplicável, adicione screenshots.

## 📋 Contexto Adicional
Qualquer outra informação relevante.
```

## 🏷️ Labels Recomendadas

### Backend Labels
- `🐛 bug` - Bugs
- `✨ enhancement` - Melhorias
- `📚 documentation` - Documentação
- `🔧 backend` - Backend específico
- `🚀 performance` - Performance
- `🔒 security` - Segurança
- `🧪 tests` - Testes
- `🐳 docker` - Docker
- `📦 dependencies` - Dependências

### Frontend Labels
- `🐛 bug` - Bugs
- `✨ enhancement` - Melhorias
- `📚 documentation` - Documentação
- `🎨 frontend` - Frontend específico
- `🎯 ui` - Interface
- `📱 responsive` - Responsividade
- `♿ accessibility` - Acessibilidade
- `🧪 tests` - Testes
- `📦 dependencies` - Dependências

## 🔐 Secrets Configuration

### Backend Secrets
```bash
# Repository Settings > Secrets and variables > Actions

HEROKU_API_KEY=your_heroku_api_key
DATABASE_URL=your_production_database_url
JWT_SECRET_KEY=your_jwt_secret
FLASK_SECRET_KEY=your_flask_secret
```

### Frontend Secrets
```bash
# Repository Settings > Secrets and variables > Actions

VERCEL_TOKEN=your_vercel_token
ORG_ID=your_vercel_org_id
PROJECT_ID=your_vercel_project_id
VITE_API_URL=https://packs-backend.herokuapp.com/api
```

## 📊 Project Management

### GitHub Projects
```bash
# Criar projeto: "PACKS E-commerce Development"

Columns:
- 📋 Backlog
- 🔄 In Progress  
- 👀 Review
- ✅ Done

# Automatizar com GitHub Actions
```

### Milestones
```bash
# Backend Milestones
- v1.0.0 - MVP Backend
- v1.1.0 - Authentication
- v1.2.0 - Payment Integration
- v2.0.0 - Admin Panel

# Frontend Milestones  
- v1.0.0 - MVP Frontend
- v1.1.0 - User Dashboard
- v1.2.0 - Checkout Flow
- v2.0.0 - Mobile App
```

## 🤝 Contribution Guidelines

### Pull Request Template (.github/pull_request_template.md)

```markdown
## 📋 Descrição
Breve descrição das mudanças.

## 🔄 Tipo de Mudança
- [ ] 🐛 Bug fix
- [ ] ✨ Nova feature
- [ ] 💥 Breaking change
- [ ] 📚 Documentação
- [ ] 🧪 Testes

## 🧪 Testes
- [ ] Testes passando
- [ ] Novos testes adicionados
- [ ] Cobertura mantida/melhorada

## 📋 Checklist
- [ ] Código segue style guide
- [ ] Self-review realizado
- [ ] Documentação atualizada
- [ ] Sem conflitos de merge
```

## 🔗 Repository Links

### Backend
- **Repository**: https://github.com/SEU_USUARIO/packs-backend
- **Issues**: https://github.com/SEU_USUARIO/packs-backend/issues
- **Actions**: https://github.com/SEU_USUARIO/packs-backend/actions
- **Releases**: https://github.com/SEU_USUARIO/packs-backend/releases

### Frontend
- **Repository**: https://github.com/SEU_USUARIO/packs-frontend
- **Issues**: https://github.com/SEU_USUARIO/packs-frontend/issues
- **Actions**: https://github.com/SEU_USUARIO/packs-frontend/actions
- **Releases**: https://github.com/SEU_USUARIO/packs-frontend/releases

---

**PACKS Streetwear** - Repositórios profissionais para streetwear autêntico! 🚀

