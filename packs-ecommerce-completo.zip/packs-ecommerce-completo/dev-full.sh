#!/bin/bash

# PACKS E-commerce - Script de Desenvolvimento Conjunto
echo "🚀 Iniciando PACKS E-commerce (Frontend + Backend)..."

# Verificar se os diretórios existem
if [ ! -d "packs-backend" ]; then
    echo "❌ Diretório packs-backend não encontrado"
    echo "   Execute este script no diretório que contém packs-backend e packs-frontend"
    exit 1
fi

if [ ! -d "packs-frontend" ]; then
    echo "❌ Diretório packs-frontend não encontrado"
    echo "   Execute este script no diretório que contém packs-backend e packs-frontend"
    exit 1
fi

# Função para cleanup ao sair
cleanup() {
    echo ""
    echo "🛑 Parando servidores..."
    kill $(jobs -p) 2>/dev/null
    echo "✅ Servidores parados"
    exit 0
}

# Capturar sinais para cleanup
trap cleanup SIGINT SIGTERM

# Verificar se o ambiente virtual do backend existe
if [ ! -d "packs-backend/venv" ]; then
    echo "⚠️ Ambiente virtual do backend não encontrado"
    echo "   Execute: cd packs-backend && ./scripts/setup.sh"
    exit 1
fi

# Verificar se as dependências do frontend estão instaladas
if [ ! -d "packs-frontend/node_modules" ]; then
    echo "⚠️ Dependências do frontend não encontradas"
    echo "   Execute: cd packs-frontend && ./scripts/setup.sh"
    exit 1
fi

# Iniciar backend
echo "🐍 Iniciando backend..."
cd packs-backend

# Ativar ambiente virtual
source venv/bin/activate

# Verificar se o banco de dados existe
if [ ! -f "database/packs.db" ]; then
    echo "🗄️ Inicializando banco de dados..."
    python -c "from app import create_app; from app.models import db; app = create_app(); app.app_context().push(); db.create_all()"
fi

# Iniciar backend em background
python run.py &
BACKEND_PID=$!

cd ..

# Aguardar backend inicializar
echo "⏳ Aguardando backend inicializar..."
sleep 5

# Verificar se backend está rodando
if curl -s http://localhost:5000/api/health > /dev/null 2>&1; then
    echo "✅ Backend iniciado com sucesso"
else
    echo "⚠️ Backend pode não estar respondendo corretamente"
fi

# Iniciar frontend
echo "🎨 Iniciando frontend..."
cd packs-frontend

# Verificar qual gerenciador de pacotes usar
if command -v pnpm &> /dev/null; then
    PACKAGE_MANAGER="pnpm"
elif command -v yarn &> /dev/null; then
    PACKAGE_MANAGER="yarn"
else
    PACKAGE_MANAGER="npm"
fi

# Iniciar frontend em background
case $PACKAGE_MANAGER in
    "pnpm")
        pnpm run dev --host &
        ;;
    "yarn")
        yarn dev --host &
        ;;
    "npm")
        npm run dev -- --host &
        ;;
esac

FRONTEND_PID=$!

cd ..

# Aguardar frontend inicializar
echo "⏳ Aguardando frontend inicializar..."
sleep 5

echo ""
echo "✅ PACKS E-commerce iniciado com sucesso!"
echo ""
echo "🌐 URLs disponíveis:"
echo "   Frontend:    http://localhost:5173"
echo "   Backend:     http://localhost:5000"
echo "   API Health:  http://localhost:5000/api/health"
echo ""
echo "📊 Status dos serviços:"

# Verificar status do backend
if curl -s http://localhost:5000/api/health > /dev/null 2>&1; then
    echo "   ✅ Backend: Rodando"
else
    echo "   ❌ Backend: Não responde"
fi

# Verificar status do frontend
if curl -s http://localhost:5173 > /dev/null 2>&1; then
    echo "   ✅ Frontend: Rodando"
else
    echo "   ❌ Frontend: Não responde"
fi

echo ""
echo "💡 Dicas:"
echo "   - Use Ctrl+C para parar ambos os servidores"
echo "   - Logs do backend: tail -f packs-backend/logs/app.log"
echo "   - Logs do frontend: visíveis neste terminal"
echo "   - Para desenvolvimento, mantenha ambos rodando"
echo ""
echo "🔧 Desenvolvimento:"
echo "   - Backend: Edite arquivos em packs-backend/app/"
echo "   - Frontend: Edite arquivos em packs-frontend/src/"
echo "   - Hot reload está ativo em ambos"
echo ""

# Aguardar os processos
wait

